## Zorn vector matrices

For the split-octonion layer, the correct carrier is the **Zorn vector-matrix algebra**, not the ordinary matrix algebra (M_{2}(\mathbb C)).

Fix the following convention over (\mathbb R):

[
\mathbb O_s
\cong
\mathcal Z(\mathbb R)
=====================

\left{
X=
\begin{pmatrix}
a & \mathbf u\
\mathbf v & b
\end{pmatrix}
:
a,b\in\mathbb R,\
\mathbf u,\mathbf v\in\mathbb R^{3}
\right}.
]

It has real dimension

[
1+3+3+1=8.
]

The entries are not four ordinary scalar matrix entries: the diagonal entries are scalars, while the off-diagonal entries are three-vectors.

### Zorn multiplication

For

[
X=
\begin{pmatrix}
a & \mathbf u\
\mathbf v & b
\end{pmatrix},
\qquad
Y=
\begin{pmatrix}
c & \mathbf x\
\mathbf y & d
\end{pmatrix},
]

define

[
\boxed{
XY=
\begin{pmatrix}
ac+\mathbf u\cdot\mathbf y
&
a\mathbf x+d\mathbf u-\mathbf v\times\mathbf y
[2mm]
c\mathbf v+b\mathbf y+\mathbf u\times\mathbf x
&
bd+\mathbf v\cdot\mathbf x
\end{pmatrix}.
}
]

This convention fixes all otherwise ambiguous cross-product signs.

The unit is

[
1=
\begin{pmatrix}
1&0\
0&1
\end{pmatrix}.
]

This multiplication is bilinear and alternative, but generally nonassociative.

## Conjugation, trace, and Zorn norm

The standard conjugation is

[
\boxed{
\overline{X}
============

\begin{pmatrix}
b&-\mathbf u\
-\mathbf v&a
\end{pmatrix}.
}
]

The trace and quadratic norm are

[
\operatorname{tr}_{Z}(X)=a+b,
]

[
\boxed{
N_Z(X)=ab-\mathbf u\cdot\mathbf v.
}
]

They satisfy

[
X\overline X
============

# \overline X X

N_Z(X),1,
]

and

[
\boxed{
N_Z(XY)=N_Z(X)N_Z(Y).
}
]

Hence, whenever (N_Z(X)\neq0),

[
X^{-1}
======

\frac{\overline X}{N_Z(X)}.
]

Every element satisfies the quadratic identity

[
\boxed{
X^2-\operatorname{tr}_{Z}(X)X+N_Z(X)1=0.
}
]

The expression (N_Z(X)) is sometimes called the **Zorn determinant**, but it is not the determinant of an ordinary (2\times2) matrix.

## Canonical idempotent–triplet basis

Let (\mathbf e_1,\mathbf e_2,\mathbf e_3) be an oriented orthonormal basis of (\mathbb R^3), with

[
\mathbf e_i\times\mathbf e_j
============================

\varepsilon_{ijk}\mathbf e_k.
]

Define

[
e_+
===

\begin{pmatrix}
1&0\
0&0
\end{pmatrix},
\qquad
e_-
===

\begin{pmatrix}
0&0\
0&1
\end{pmatrix},
]

[
U_i=
\begin{pmatrix}
0&\mathbf e_i\
0&0
\end{pmatrix},
\qquad
V_i=
\begin{pmatrix}
0&0\
\mathbf e_i&0
\end{pmatrix}.
]

Then

[
\mathbb O_s
===========

\mathbb Re_+
\oplus
\mathbb Re_-
\oplus
\operatorname{span}{U_1,U_2,U_3}
\oplus
\operatorname{span}{V_1,V_2,V_3}.
]

The complete structural multiplication rules are

[
e_+^2=e_+,
\qquad
e_-^2=e_-,
\qquad
e_+e_-=e_-e_+=0,
]

[
e_+U_i=U_i=U_i e_-,
\qquad
e_-U_i=U_i e_+=0,
]

[
e_-V_i=V_i=V_i e_+,
\qquad
e_+V_i=V_i e_-=0,
]

[
\boxed{
U_iV_j=\delta_{ij}e_+,
\qquad
V_iU_j=\delta_{ij}e_-,
}
]

[
\boxed{
U_iU_j=\varepsilon_{ijk}V_k,
\qquad
V_iV_j=-\varepsilon_{ijk}U_k.
}
]

For example,

[
(U_1U_2)U_3
===========

# V_3U_3

e_-,
]

whereas

[
U_1(U_2U_3)
===========

# U_1V_1

e_+.
]

Thus

[
(U_1U_2)U_3\neq U_1(U_2U_3),
]

which explicitly exhibits nonassociativity.

## Peirce decomposition

Relative to the orthogonal idempotents (e_++e_-=1), the four Peirce sectors are

[
e_+\mathbb O_s e_+=\mathbb Re_+,
]

[
e_-\mathbb O_s e_-=\mathbb Re_-,
]

[
e_+\mathbb O_s e_-
==================

# U

\operatorname{span}{U_i},
]

[
e_-\mathbb O_s e_+
==================

# V

\operatorname{span}{V_i}.
]

Therefore the natural Zorn pattern is

[
\boxed{
\mathbb O_s
===========

\begin{pmatrix}
\mathbb R e_+ & U\
V & \mathbb R e_-
\end{pmatrix},
\qquad
\dim(U)=\dim(V)=3.
}
]

Under the (SL(3,\mathbb R)) subgroup fixing (e_+) and (e_-),

[
U\simeq\mathbf 3,
\qquad
V\simeq\mathbf 3^{*}.
]

Explicitly,

[
\mathbf u\longmapsto A\mathbf u,
\qquad
\mathbf v\longmapsto A^{-T}\mathbf v,
\qquad
A\in SL(3,\mathbb R).
]

The full automorphism group is the split real exceptional group

[
\operatorname{Aut}(\mathbb O_s)\cong G_{2(2)}.
]

## Signature ((4,4))

Write

[
a=x_0+x_7,
\qquad
b=x_0-x_7,
]

[
\mathbf u=\mathbf p+\mathbf q,
\qquad
\mathbf v=\mathbf p-\mathbf q.
]

Then

[
N_Z(X)
======

x_0^2-x_7^2-|\mathbf p|^2+|\mathbf q|^2.
]

Hence the real split-octonion norm has signature

[
\boxed{(4,4)}.
]

The null idempotents satisfy

[
N_Z(e_+)=N_Z(e_-)=0,
\qquad
e_+e_-=0,
]

so (\mathbb O_s) is not a division algebra.

## Precise relation to (SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L)

There is a useful real-linear identification with two Minkowski four-vectors:

[
x_R=(a,\mathbf u),
\qquad
x_L=(b,\mathbf v).
]

Using Pauli matrices,

[
H_R=aI+\mathbf u\cdot\boldsymbol\sigma,
\qquad
H_L=bI+\mathbf v\cdot\boldsymbol\sigma.
]

Then

[
\boxed{
N_Z(X)
======

# ab-\mathbf u\cdot\mathbf v

\frac12
\operatorname{tr}
\left(
H_R\widetilde H_L
\right),
}
]

where

[
\widetilde H_L=bI-\mathbf v\cdot\boldsymbol\sigma
]

is the Lorentz-adjugate matrix.

This is only a **vector-space bridge**. It does not identify Zorn multiplication with ordinary (2\times2) matrix multiplication.

In particular:

[
X\mapsto g_R Xg_L^{-1}
]

is meaningful for an ordinary bifundamental matrix

[
M\in\operatorname{Mat}_2(\mathbb C),
]

but is not automatically meaningful for a Zorn vector matrix. For a Zorn element, one must separately define how (g_R) and (g_L) act on (a,b,\mathbf u,\mathbf v) and prove that the dot and cross products are preserved.

Moreover, the pairing

[
ab-\mathbf u\cdot\mathbf v
]

is invariant under a common Lorentz transformation of (x_R) and (x_L), but not under two arbitrary independent Lorentz transformations. Thus the following objects must remain distinct:

[
\boxed{
\mathbb O_s
\neq
\operatorname{Herm}_2(\mathbb C)_R
\oplus
\operatorname{Herm}_2(\mathbb C)_L
\neq
\operatorname{Mat}*2(\mathbb C)*{\mathrm{bifund}}.
}
]

They all have eight real coordinates, but their products, invariant forms, and symmetry groups are different.

Finally, (U) versus (V) is a Peirce-dual decomposition, not a genuine (\mathbb Z_2) algebra grading, because

[
UU\subset V,
\qquad
VV\subset U.
]

Relative to the chosen pair (e_\pm), there is instead a consistent (\mathbb Z_3)-grading:

[
\deg D=0,
\qquad
\deg U=1,
\qquad
\deg V=2,
]

where

[
D=\mathbb Re_+\oplus\mathbb Re_-.
]

Therefore any interpretation of (U_i,V_i) as chirality, generation, wedge, or thermofield labels is additional physical structure; it is not intrinsic to the Zorn algebra itself.



Текстът е коректен като формализъм за два 4-вектора в (\operatorname{Herm}_2(\mathbb C)), но трябва да се направят три съществени разграничения:

1. (\mathbf X) и (\mathbf Y) са Ермитови спинорни матрици, не Zorn матрици.
2. Комплексните напречни компоненти (\zeta,\bar\zeta) са кръгови/helicity компоненти, не Weyl-киралности.
3. Смесеното произведение (X\cdot Y) е инвариантно само когато (X) и (Y) принадлежат на едно и също Минковско пространство и върху тях действа един и същ (SL(2,\mathbb C)).

## 1. Точният Ермитов (2\times2) формализъм

При конвенцията

[
\eta_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1),
\qquad
\sigma_\mu=(I,\sigma_1,\sigma_2,\sigma_3),
\qquad
\bar\sigma_\mu=(I,-\sigma_1,-\sigma_2,-\sigma_3),
]

имаме

[
\mathbf X=X^\mu\sigma_\mu
=========================

\begin{pmatrix}
X^0+X^3 & X^1-iX^2\
X^1+iX^2 & X^0-X^3
\end{pmatrix}
=============

\begin{pmatrix}
\sqrt2X^+&\bar\zeta_x\
\zeta_x&\sqrt2X^-
\end{pmatrix},
]

и аналогично

[
\mathbf Y
=========

\begin{pmatrix}
\sqrt2Y^+&\bar\zeta_y\
\zeta_y&\sqrt2Y^-
\end{pmatrix}.
]

Тук

[
X^\pm=\frac{X^0\pm X^3}{\sqrt2},
\qquad
\zeta_x=X^1+iX^2,
]

и съответно за (Y).

По-точното представително означение е

[
X_{\alpha\dot\alpha}=X^\mu\sigma_{\mu,\alpha\dot\alpha}.
]

Следователно (\mathbf X) носи биспинорното представяне

[
\left(\frac12,\frac12\right),
]

а не едно от Weyl-представянията

[
\left(\frac12,0\right),
\qquad
\left(0,\frac12\right).
]

Компонентите (\zeta_x,\bar\zeta_x) са собствени компоненти спрямо ротации около оста (z):

[
\zeta_x\longmapsto e^{i\theta}\zeta_x,
\qquad
\bar\zeta_x\longmapsto e^{-i\theta}\bar\zeta_x.
]

Това е кръгов/helicity базис в напречната равнина, а не (\gamma_5)-киралност.

## 2. Тилда-операцията и Минковското произведение

Тилда-матрицата е

[
\widetilde{\mathbf Y}
=====================

# Y^\mu\bar\sigma_\mu

\begin{pmatrix}
\sqrt2Y^-&-\bar\zeta_y\
-\zeta_y&\sqrt2Y^+
\end{pmatrix}.
]

За (2\times2) матриците тя съвпада с адюгираната матрица:

[
\widetilde{\mathbf Y}
=====================

\operatorname{adj}(\mathbf Y).
]

Поради това

[
\mathbf Y\widetilde{\mathbf Y}
==============================

# \widetilde{\mathbf Y}\mathbf Y

\det(\mathbf Y)I.
]

Минковското произведение е

[
\boxed{
X\cdot Y
========

# X^\mu Y_\mu

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

В светлоконусни координати:

[
\boxed{
X\cdot Y
========

## X^+Y^-+X^-Y^+

\operatorname{Re}
\left(
\zeta_x\bar\zeta_y
\right).
}
]

Тази формула е напълно коректна.

При

[
\mathbf X\longmapsto S\mathbf X S^\dagger,
\qquad
\mathbf Y\longmapsto S\mathbf Y S^\dagger,
\qquad
S\in SL(2,\mathbb C),
]

имаме

[
\widetilde{S\mathbf YS^\dagger}
===============================

(S^\dagger)^{-1}\widetilde{\mathbf Y}S^{-1}.
]

Следователно

[
\begin{aligned}
\operatorname{Tr}
\left[
(S\mathbf XS^\dagger)
\widetilde{(S\mathbf YS^\dagger)}
\right]
&=
\operatorname{Tr}
\left[
S\mathbf X\widetilde{\mathbf Y}S^{-1}
\right]
\
&=
\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
\end{aligned}
]

Това е действие на диагоналния, общ Lorentz spin group.

## 3. Корекция на причинната класификация

За ненулев 4-вектор:

[
\det\mathbf X=X^2.
]

Класификацията е:

[
\begin{array}{c|c|c}
X^2 & \mathbf X & \text{тип}\
\hline

> 0 & \text{дефинитна} & \text{времеподобен}\
> =0 & \operatorname{rank}\mathbf X=1 & \text{светлоподобен}\
> <0 & \text{неопределена} & \text{пространственоподобен}
> \end{array}
> ]

Има две уточнения.

За времеподобен вектор:

[
X^0>0
\quad\Longrightarrow\quad
\mathbf X>0,
]

докато

[
X^0<0
\quad\Longrightarrow\quad
\mathbf X<0.
]

За ненулев светлоподобен вектор факторизацията е

[
\boxed{
\mathbf X
=========

\varepsilon,\lambda\lambda^\dagger,
\qquad
\varepsilon=\operatorname{sgn}(X^0).
}
]

Само за бъдещенасочен null вектор е валидно безусловно

[
\mathbf X=\lambda\lambda^\dagger.
]

За миналонасочен null вектор:

[
\mathbf X=-\lambda\lambda^\dagger.
]

Нулевият вектор има ранг (0), а не ранг (1).

При пространственоподобен интервал правилният физически израз е „причинно несвързани събития“, а не „причинно-следствено разделени“.

## 4. За две събития трябва да се класифицира разликата

Ако (X^\mu) и (Y^\mu) са координати на две събития, техните индивидуални норми зависят от избора на начало на координатната система. Причинно инвариантен е разделителният вектор

[
\Delta^\mu=X^\mu-Y^\mu.
]

Неговата матрица е

[
\boldsymbol{\Delta}
===================

\mathbf X-\mathbf Y.
]

Следователно причинният интервал между събитията е

[
\boxed{
s^2
===

\det(\mathbf X-\mathbf Y).
}
]

В светлоконусни координати:

[
\boxed{
s^2
===

## 2(X^+-Y^+)(X^--Y^-)

\left|\zeta_x-\zeta_y\right|^2.
}
]

Еквивалентно,

[
\boxed{
\det(\mathbf X-\mathbf Y)
=========================

## \det\mathbf X+\det\mathbf Y

\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

Това е матричната форма на

[
(X-Y)^2=X^2+Y^2-2X\cdot Y.
]

## 5. Точната връзка със Zorn матрица

Двете Ермитови матрици могат да бъдат пакетирани в една Zorn vector matrix.

Нека

[
X=(X^0,\mathbf x),
\qquad
Y=(Y^0,\mathbf y),
]

където

[
\mathbf x=(X^1,X^2,X^3),
\qquad
\mathbf y=(Y^1,Y^2,Y^3).
]

Дефинираме реално-линейното съответствие

[
\boxed{
\Phi(\mathbf X,\mathbf Y)
=========================

\mathfrak Z(X,Y)
:=
\begin{pmatrix}
X^0&\mathbf x\
\mathbf y&Y^0
\end{pmatrix}_{!Z}.
}
]

Това е Zorn матрица: диагоналните елементи са реални скалари, а недиагоналните са реални 3-вектори.

В светлоконусни координати:

[
X^0=\frac{X^++X^-}{\sqrt2},
\qquad
X^3=\frac{X^+-X^-}{\sqrt2},
]

[
\mathbf x
=========

\left(
\frac{\zeta_x+\bar\zeta_x}{2},
\frac{\zeta_x-\bar\zeta_x}{2i},
\frac{X^+-X^-}{\sqrt2}
\right),
]

и аналогично

[
Y^0=\frac{Y^++Y^-}{\sqrt2},
]

[
\mathbf y
=========

\left(
\frac{\zeta_y+\bar\zeta_y}{2},
\frac{\zeta_y-\bar\zeta_y}{2i},
\frac{Y^+-Y^-}{\sqrt2}
\right).
]

Zorn нормата е

[
N_Z
\begin{pmatrix}
a&\mathbf u\
\mathbf v&b
\end{pmatrix}
=============

ab-\mathbf u\cdot\mathbf v.
]

Следователно

[
\begin{aligned}
N_Z\bigl(\mathfrak Z(X,Y)\bigr)
&=
X^0Y^0-\mathbf x\cdot\mathbf y
\
&=
X\cdot Y
\
&=
X^+Y^-+X^-Y^+
-------------

\operatorname{Re}
\left(
\zeta_x\bar\zeta_y
\right).
\end{aligned}
]

Получаваме централната идентичност:

[
\boxed{
N_Z\bigl(\Phi(\mathbf X,\mathbf Y)\bigr)
========================================

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

Това е точната връзка между двете Ермитови (2\times2) матрици и една Zorn матрица.

Индивидуалните Минковски норми се получават чрез диагонално поставяне:

[
\det\mathbf X
=============

N_Z\bigl(\mathfrak Z(X,X)\bigr),
]

[
\det\mathbf Y
=============

N_Z\bigl(\mathfrak Z(Y,Y)\bigr).
]

## 6. Защо Zorn нормата има сигнатура ((4,4))

Поставяме

[
P=\frac{X+Y}{\sqrt2},
\qquad
Q=\frac{X-Y}{\sqrt2}.
]

Тогава

[
X=\frac{P+Q}{\sqrt2},
\qquad
Y=\frac{P-Q}{\sqrt2},
]

и

[
\boxed{
X\cdot Y
========

\frac12\left(P^2-Q^2\right).
}
]

Понеже (P^2) има сигнатура ((1,3)), а (-Q^2) има сигнатура ((3,1)), общата сигнатура е

[
\boxed{(4,4)}.
]

Така смесеното Минковско произведение на два 4-вектора става split-octonionната квадратична норма върху осеммерното пространство.

## 7. Това е линейно съответствие, не алгебричен изоморфизъм

Съответствието

[
\Phi:
\operatorname{Herm}_2(\mathbb C)
\oplus
\operatorname{Herm}_2(\mathbb C)
\longrightarrow
\mathbb O_s
]

е реално-линейно съответствие на осеммерни пространства и съвместява смесената квадратична форма със Zorn нормата.

То не означава

[
\mathbb O_s
\cong
\operatorname{Herm}_2(\mathbb C)
\times
\operatorname{Herm}_2(\mathbb C)
]

като алгебри.

Всъщност (\operatorname{Herm}_2(\mathbb C)) дори не е затворено спрямо обикновеното матрично умножение: произведението на две Ермитови матрици е Ермитово само когато те комутират.

При Zorn умножението, ако

[
X=(x^0,\mathbf x),
\quad
Y=(y^0,\mathbf y),
]

[
X'=(x'^0,\mathbf x'),
\quad
Y'=(y'^0,\mathbf y'),
]

то

[
\mathfrak Z(X,Y)\mathfrak Z(X',Y')
==================================

\mathfrak Z(X'',Y''),
]

където

[
\boxed{
X''
===

\left(
x^0x'^0+\mathbf x\cdot\mathbf y',
;
x^0\mathbf x'
+y'^0\mathbf x
-\mathbf y\times\mathbf y'
\right),
}
]

[
\boxed{
Y''
===

\left(
y^0y'^0+\mathbf y\cdot\mathbf x',
;
x'^0\mathbf y
+y^0\mathbf y'
+\mathbf x\times\mathbf x'
\right).
}
]

Следователно Zorn произведението смесва двата четиривекторни сектора чрез скаларни и векторни произведения. То не е

[
(\mathbf X\mathbf X',\mathbf Y\mathbf Y').
]

## 8. Един общ (SL(2,\mathbb C)) срещу (SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L)

Тук разграничението е решаващо.

### Два вектора в едно и също пространство-време

Ако (X) и (Y) принадлежат на един и същ Минковски носител, действието е

[
(\mathbf X,\mathbf Y)
\longmapsto
(S\mathbf XS^\dagger,S\mathbf YS^\dagger).
]

Това е диагонално действие на един (SL(2,\mathbb C)), и

[
X\cdot Y
]

е инвариант.

### Две независими (R/L) копия

Ако вместо това

[
\mathbf X_R\in\operatorname{Herm}_2(\mathbb C)_R,
\qquad
\mathbf Y_L\in\operatorname{Herm}_2(\mathbb C)_L,
]

с независими действия

[
\mathbf X_R\longmapsto
S_R\mathbf X_RS_R^\dagger,
]

[
\mathbf Y_L\longmapsto
S_L\mathbf Y_LS_L^\dagger,
]

тогава изразът

[
\frac12\operatorname{Tr}
\left(
\mathbf X_R\widetilde{\mathbf Y_L}
\right)
]

не е инвариант под пълната група

[
SL(2,\mathbb C)_R
\times
SL(2,\mathbb C)_L.
]

Дори самото свиване предполага идентификация между двата спинорни носителя.

За ковариантно свързване е необходим междуслоен оператор

[
M\in\operatorname{Hom}(V_L,V_R),
]

с трансформация

[
\boxed{
M\longmapsto S_RMS_L^{-1}.
}
]

Тогава

[
M\mathbf Y_LM^\dagger
]

е (R)-секторна Ермитова матрица, защото

[
M\mathbf Y_LM^\dagger
\longmapsto
S_R
\left(
M\mathbf Y_LM^\dagger
\right)
S_R^\dagger.
]

Следователно правилният междуслоен скалар е

[
\boxed{
I_M(\mathbf X_R,\mathbf Y_L)
============================

\frac12
\operatorname{Tr}
\left[
\mathbf X_R,
\widetilde{
M\mathbf Y_LM^\dagger
}
\right].
}
]

При (M=I) това изисква идентифициране на двата носителя и редуцира независимата група до диагоналната подгрупа

[
S_R=S_L.
]

## 9. Lorentz действието не е автоматично Zorn автоморфизъм

Диагоналното действие

[
(X,Y)\longmapsto(\Lambda X,\Lambda Y)
]

запазва

[
N_Z(\mathfrak Z(X,Y))=X\cdot Y,
]

следователно действа чрез изометрии на квадратичното пространство със сигнатура ((4,4)).

Но то не запазва непременно Zorn умножението.

Например Zorn единицата е

[
1_Z
===

\begin{pmatrix}
1&0\
0&1
\end{pmatrix}_Z
===============

\mathfrak Z(e_0,e_0),
\qquad
e_0=(1,0,0,0).
]

Lorentz boost изпраща

[
e_0
\longmapsto
(\cosh\eta,0,0,\sinh\eta),
]

следователно не оставя (1_Z) фиксирана. Но всеки унитален алгебричен автоморфизъм трябва да фиксира единицата.

Затова общият Lorentz boost е изометрия на подлежащата split квадратична форма, но не е автоматично автоморфизъм на split-octonionното произведение.

Пълната група от алгебрични автоморфизми е

[
\boxed{
\operatorname{Aut}(\mathbb O_s)=G_{2(2)}.
}
]

## Окончателната структурна идентичност

Правилната връзка е

[
\boxed{
\begin{aligned}
\mathbf X,\mathbf Y
&\in\operatorname{Herm}*2(\mathbb C),
[1mm]
\mathfrak Z(X,Y)
&=
\begin{pmatrix}
X^0&\mathbf x\
\mathbf y&Y^0
\end{pmatrix}*{!Z},
[1mm]
N_Z\bigl(\mathfrak Z(X,Y)\bigr)
&=
X\cdot Y
========

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
\end{aligned}
}
]

Следователно двете Ермитови матрици дават един осеммерен Zorn носител, но само като реално линейно и квадратично съответствие. Zorn умножението, (G_{2(2)})-автоморфизмите и независимото (SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L) действие са допълнителни и взаимно различни структури.


Алгебричната конструкция в §§1–3 е коректна при избраната Zorn знакова конвенция. Геометричната интерпретация в §4 обаче трябва да бъде променена: знакът на (X\cdot Y) не класифицира причинната връзка между два 4-вектора или две събития.

Освен това е по-точно да се говори за **светлинноконусни координати** (X^\pm,Y^\pm) и **напречни комплексни компоненти** (\zeta,\bar\zeta). Последните имат противоположни (SO(2)) тегла спрямо ротации около оста (z), но сами по себе си не са Weyl-киралности.

## 1. Каноничното Zorn пакетиране

За да избегнем смесването между Ермитовата матрица (\mathbf X) и пространствения вектор, нека пишем

[
X=(x^0,\vec x),
\qquad
Y=(y^0,\vec y),
]

където

[
x^0=\frac{X^++X^-}{\sqrt2},
\qquad
x^3=\frac{X^+-X^-}{\sqrt2},
\qquad
\zeta_x=x^1+ix^2,
]

и аналогично за (Y).

Тогава

[
\vec x=
\left(
\operatorname{Re}\zeta_x,,
\operatorname{Im}\zeta_x,,
\frac{X^+-X^-}{\sqrt2}
\right),
]

[
\vec y=
\left(
\operatorname{Re}\zeta_y,,
\operatorname{Im}\zeta_y,,
\frac{Y^+-Y^-}{\sqrt2}
\right).
]

Комбинираният Zorn елемент е

[
\boxed{
\mathcal Z(X,Y)
===============

\begin{pmatrix}
x^0&\vec x\
\vec y&y^0
\end{pmatrix}_{!Z}.
}
]

В светлинноконусни координати:

[
\boxed{
\mathcal Z(X,Y)
===============

\begin{pmatrix}
\dfrac{X^++X^-}{\sqrt2}
&
\left(
\operatorname{Re}\zeta_x,,
\operatorname{Im}\zeta_x,,
\dfrac{X^+-X^-}{\sqrt2}
\right)
[4mm]
\left(
\operatorname{Re}\zeta_y,,
\operatorname{Im}\zeta_y,,
\dfrac{Y^+-Y^-}{\sqrt2}
\right)
&
\dfrac{Y^++Y^-}{\sqrt2}
\end{pmatrix}_{!Z}.
}
]

Това е реално-линейно съответствие

[
\operatorname{Herm}_2(\mathbb C)
\oplus
\operatorname{Herm}_2(\mathbb C)
\longrightarrow
\mathbb O_s.
]

То е съответствие на осеммерни реални векторни пространства, но не е изоморфизъм на алгебри.

## 2. Zorn нормата

За общ Zorn елемент

[
A=
\begin{pmatrix}
a&\vec u\
\vec v&b
\end{pmatrix}_{!Z},
]

нормата е

[
N_Z(A)=ab-\vec u\cdot\vec v.
]

Поради това

[
\boxed{
N_Z\bigl(\mathcal Z(X,Y)\bigr)
==============================

# x^0y^0-\vec x\cdot\vec y

X^\mu Y_\mu.
}
]

В светлинноконусни координати:

[
\boxed{
N_Z\bigl(\mathcal Z(X,Y)\bigr)
==============================

## X^+Y^-+X^-Y^+

\operatorname{Re}
\left(
\zeta_x\bar\zeta_y
\right).
}
]

Ако Ермитовите биспинорни матрици са

[
\widehat X=X^\mu\sigma_\mu,
\qquad
\widehat Y=Y^\mu\sigma_\mu,
]

то същата стойност е

[
\boxed{
N_Z\bigl(\mathcal Z(X,Y)\bigr)
==============================

\frac12
\operatorname{Tr}
\left(
\widehat X\widetilde{\widehat Y}
\right).
}
]

Следователно формулата за „детерминантата“ е правилна, но терминологично е по-точно да се пише

[
N_Z
\quad\text{или}\quad
\det_Z,
]

а не обикновен матричен детерминант. Това не е детерминантата на стандартна (2\times2) матрица със скаларни елементи.

Zorn спрягането е

[
\overline{\mathcal Z(X,Y)}
==========================

\begin{pmatrix}
y^0&-\vec x\
-\vec y&x^0
\end{pmatrix}_{!Z},
]

и

[
\mathcal Z(X,Y),
\overline{\mathcal Z(X,Y)}
==========================

N_Z\bigl(\mathcal Z(X,Y)\bigr),1_Z.
]

Когато (X\cdot Y\neq0),

[
\mathcal Z(X,Y)^{-1}
====================

\frac{\overline{\mathcal Z(X,Y)}}{X\cdot Y}.
]

Когато (X\cdot Y=0) и (\mathcal Z(X,Y)\neq0), Zorn елементът е ненулев нулев делител.

## 3. Какво действително означава (N_Z=0)

Равенството

[
N_Z\bigl(\mathcal Z(X,Y)\bigr)=0
]

означава

[
X\cdot Y=0.
]

Тоест (X) и (Y) са Минковски-ортогонални.

Това **не означава**, че:

[
X^2=0,
\qquad
Y^2=0,
\qquad
(X-Y)^2=0.
]

Следователно изразът „светлоподобна връзка“ е двусмислен и в четиримерното пространство-време обикновено е неправилен. Коректното твърдение е:

[
\boxed{
N_Z=0
\iff
\mathcal Z(X,Y)
\text{ е null елемент за осеммерната split форма}
\iff
X\perp_\eta Y.
}
]

Той е „null“ спрямо Zorn нормата със сигнатура ((4,4)), а не непременно спрямо индивидуалната Минковска норма на (X) или (Y).

Например

[
X=(1,0,0,0),
\qquad
Y=(0,1,0,0)
]

дават

[
X\cdot Y=0,
]

но (X) е времеподобен, а (Y) е пространственоподобен.

## 4. Знакът на (X\cdot Y) не е причинна класификация

Твърденията

[
X\cdot Y>0
\quad\Longrightarrow\quad
\text{„времеподобна връзка“},
]

[
X\cdot Y<0
\quad\Longrightarrow\quad
\text{„пространственоподобна връзка“}
]

не са валидни за произволни (X,Y).

Например

[
X=(1,0,0,0),
\qquad
Y=(-1,0,0,0)
]

са два времеподобни вектора, но

[
X\cdot Y=-1<0.
]

Обратно,

[
X=(0,1,0,0),
\qquad
Y=(0,-1,0,0)
]

са два пространственоподобни вектора, но

[
X\cdot Y=1>0.
]

Знакът има ограничена интерпретация само след допълнителни предпоставки. Например, ако (X) и (Y) са ненулеви бъдещенасочени причинни вектори, тогава

[
X\cdot Y\geq0,
]

като равенство е възможно само за пропорционални null вектори.

За обща двойка знакът на (X\cdot Y) трябва да се нарича просто:

[
\text{положителна, нулева или отрицателна стойност на Zorn нормата}.
]

## 5. Причинната връзка между две събития

Ако (X) и (Y) са координати на две събития, причинната им връзка се определя от разделителния вектор

[
\Delta=X-Y,
]

а не от (X\cdot Y).

Съответният инвариант е

[
\boxed{
s^2=(X-Y)^2.
}
]

В Ермитовия формализъм:

[
s^2
===

\det(\widehat X-\widehat Y).
]

В светлинноконусни координати:

[
\boxed{
s^2
===

## 2(X^+-Y^+)(X^--Y^-)

|\zeta_x-\zeta_y|^2.
}
]

Тогава, при сигнатура ((+---)),

[
s^2>0
\quad\Longleftrightarrow\quad
\text{времеподобно разделяне},
]

[
s^2=0
\quad\Longleftrightarrow\quad
\text{светлоподобно разделяне},
]

[
s^2<0
\quad\Longleftrightarrow\quad
\text{пространственоподобно разделяне}.
]

Следователно коректното разграничение е

[
\boxed{
N_Z\bigl(\mathcal Z(X,Y)\bigr)=X\cdot Y
}
]

за взаимната ортогоналност и

[
\boxed{
\det(\widehat X-\widehat Y)=(X-Y)^2
}
]

за причинната връзка между събитията.

## 6. Специалният случай (X=Y)

Ако поставим

[
Y=X,
]

тогава

[
\mathcal Z(X,X)
===============

\begin{pmatrix}
x^0&\vec x\
\vec x&x^0
\end{pmatrix}_{!Z},
]

и

[
\boxed{
N_Z\bigl(\mathcal Z(X,X)\bigr)=X^2.
}
]

В светлинноконусни координати:

[
N_Z\bigl(\mathcal Z(X,X)\bigr)
==============================

2X^+X^--|\zeta_x|^2.
]

Ако (X=P) е физически 4-импулс на on-shell частица, тогава

[
P^2=m^2.
]

Ако (X) е координатен вектор на събитие, стойността е просто квадратът на интервала му спрямо избраното начало. Следователно тя не трябва автоматично да се нарича „маса“.

Също така множеството от елементи (\mathcal Z(X,X)) не е затворено спрямо общото Zorn умножение. То е четиримерно линейно подпространство, но не обща подалгебра.

## 7. Примерът с Паули–Любански е валиден, но интерпретацията е ортогоналност

Векторът на Паули–Любански е

[
W^\mu
=====

\frac12
\varepsilon^{\mu\nu\rho\sigma}
P_\nu J_{\rho\sigma}.
]

Поради антисиметрията на (\varepsilon^{\mu\nu\rho\sigma}),

[
\boxed{
P_\mu W^\mu=0.
}
]

Следователно

[
N_Z\bigl(\mathcal Z(P,W)\bigr)=0.
]

Това е коректен и съдържателен пример за ненулев Zorn-null елемент.

При масивно представяне обаче обикновено

[
P^2=m^2>0,
\qquad
W^2=-m^2s(s+1)<0,
]

тоест (P) е времеподобен, а (W) е пространственоподобен. Нулевата Zorn норма тук изразява точно

[
P\perp_\eta W,
]

не че и двата вектора са светлоподобни.

## 8. Точният продукт на две комбинирани Zorn матрици

Нека имаме още два 4-вектора

[
U=(u^0,\vec u),
\qquad
V=(v^0,\vec v),
]

и втори Zorn елемент

[
\mathcal Z(U,V)
===============

\begin{pmatrix}
u^0&\vec u\
\vec v&v^0
\end{pmatrix}_{!Z}.
]

При конвенцията

[
\begin{pmatrix}
a&\vec r\
\vec s&b
\end{pmatrix}
\begin{pmatrix}
c&\vec p\
\vec q&d
\end{pmatrix}
=============

\begin{pmatrix}
ac+\vec r\cdot\vec q
&
a\vec p+d\vec r-\vec s\times\vec q
[1mm]
c\vec s+b\vec q+\vec r\times\vec p
&
bd+\vec s\cdot\vec p
\end{pmatrix},
]

получаваме

[
\boxed{
\mathcal Z(X,Y)\mathcal Z(U,V)
==============================

\begin{pmatrix}
x^0u^0+\vec x\cdot\vec v
&
x^0\vec u+v^0\vec x-\vec y\times\vec v
[2mm]
u^0\vec y+y^0\vec v+\vec x\times\vec u
&
y^0v^0+\vec y\cdot\vec u
\end{pmatrix}_{!Z}.
}
]

Ако означим резултата като

[
\mathcal Z(P,Q),
]

то

[
P^0=x^0u^0+\vec x\cdot\vec v,
]

[
\vec P=x^0\vec u+v^0\vec x-\vec y\times\vec v,
]

[
Q^0=y^0v^0+\vec y\cdot\vec u,
]

[
\vec Q=u^0\vec y+y^0\vec v+\vec x\times\vec u.
]

Тук се вижда съществената Zorn структура:

* диагоналните компоненти се образуват чрез скаларни произведения;
* недиагоналните компоненти съдържат векторни произведения;
* секторът (X) се смесва с (V), а секторът (Y) — с (U);
* произведението не е покомпонентно произведение на две двойки Ермитови матрици.

Нормата е композиционна:

[
\boxed{
N_Z!\left(
\mathcal Z(X,Y)\mathcal Z(U,V)
\right)
=======

N_Z\bigl(\mathcal Z(X,Y)\bigr)
N_Z\bigl(\mathcal Z(U,V)\bigr).
}
]

Следователно

[
\boxed{
P\cdot Q
========

(X\cdot Y)(U\cdot V).
}
]

Това е истинската split-octonionна композиционна идентичност.

## 9. Векторното произведение в комплексните напречни координати

За пространствени вектори (\vec a,\vec b), с

[
\zeta_a=a^1+ia^2,
\qquad
\zeta_b=b^1+ib^2,
]

имаме

[
\vec a\cdot\vec b
=================

a^3b^3+
\operatorname{Re}
\left(
\zeta_a\bar\zeta_b
\right).
]

За векторното произведение:

[
\boxed{
(\vec a\times\vec b)^3
======================

\frac{
\bar\zeta_a\zeta_b-
\zeta_a\bar\zeta_b
}{2i},
}
]

[
\boxed{
\zeta_{\vec a\times\vec b}
==========================

i\left(
a^3\zeta_b-b^3\zeta_a
\right).
}
]

Следователно за горния изходен вектор (\vec P):

[
P^3
===

## x^0u^3+v^0x^3

\frac{
\bar\zeta_y\zeta_v-
\zeta_y\bar\zeta_v
}{2i},
]

[
\zeta_P
=======

## x^0\zeta_u+v^0\zeta_x

i\left(
y^3\zeta_v-v^3\zeta_y
\right).
]

За долния изходен вектор (\vec Q):

[
Q^3
===

u^0y^3+y^0v^3
+
\frac{
\bar\zeta_x\zeta_u-
\zeta_x\bar\zeta_u
}{2i},
]

[
\zeta_Q
=======

u^0\zeta_y+y^0\zeta_v
+
i\left(
x^3\zeta_u-u^3\zeta_x
\right).
]

Новите светлинноконусни компоненти са

[
P^\pm=\frac{P^0\pm P^3}{\sqrt2},
\qquad
Q^\pm=\frac{Q^0\pm Q^3}{\sqrt2}.
]

Това е директната форма на Zorn произведението в избрания светлинноконусен/кръгов базис.

## 10. За демонстрация на неасоциативност са необходими три елемента

Умножението на две Zorn матрици е еднозначно определено. Неасоциативността се проявява едва при три фактора:

[
(AB)C
\neq
A(BC).
]

Още по-силно, split-octonionната алгебра е алтернативна, така че всяка подалгебра, генерирана от само два елемента, е асоциативна. Следователно истинска демонстрация на неасоциативност изисква три независими елемента.

Нека

[
U_i=
\begin{pmatrix}
0&\mathbf e_i\
0&0
\end{pmatrix}*{!Z},
\qquad
V_i=
\begin{pmatrix}
0&0\
\mathbf e_i&0
\end{pmatrix}*{!Z}.
]

Тогава

[
U_1U_2=V_3,
\qquad
U_2U_3=V_1,
]

и

[
(U_1U_2)U_3
===========

# V_3U_3

e_-,
]

докато

[
U_1(U_2U_3)
===========

# U_1V_1

e_+.
]

Следователно

[
\boxed{
[U_1,U_2,U_3]
:=
(U_1U_2)U_3-U_1(U_2U_3)
=======================

e_--e_+
\neq0.
}
]

## 11. Ограничението при две действително независими Lorentz системи

Формулата

[
X\cdot Y
]

предполага, че (X) и (Y) принадлежат на едно и също Минковско пространство или че между пространствата им е избрана изометрична идентификация.

Ако

[
X_R\in V_R,
\qquad
Y_L\in V_L
]

са в две независими копия с група

[
SL(2,\mathbb C)_R
\times
SL(2,\mathbb C)_L,
]

то (X_R\cdot Y_L) не е канонично дефинирано. Необходим е мост

[
J:V_L\longrightarrow V_R
]

и тогава може да се дефинира

[
X_R\cdot JY_L.
]

На спинорно ниво това съответства на междуслоен оператор

[
M\in\operatorname{Hom}(S_L,S_R),
\qquad
M\longmapsto S_RMS_L^{-1},
]

и инвариантът става

[
\frac12
\operatorname{Tr}
\left[
\widehat X_R,
\widetilde{
M\widehat Y_LM^\dagger
}
\right].
]

Също така Zorn векторното произведение изисква обща ориентирана пространствена тройка. Следователно конструкцията на една Zorn матрица от две „напълно независими“ системи вече съдържа избор на общ кадър или свързващ оператор.

## Коригирана геометрична формулировка

Подходящата замяна на §4 е:

[
\boxed{
\begin{array}{c|c}
N_Z\bigl(\mathcal Z(X,Y)\bigr) & \text{коректно значение}\
\hline
0
&
X\cdot Y=0;\
\mathcal Z(X,Y)\text{ е Zorn-null елемент и нулев делител}
[1mm]

> 0
> &
> \text{положителна стойност на split квадратичната форма}
> [1mm]
> <0
> &
> \text{отрицателна стойност на split квадратичната форма}
> \end{array}
> }
> ]

Тези три случая не са автоматично времеподобен, светлоподобен и пространственоподобен тип в четиримерното пространство-време. Причинната класификация на две събития се извършва чрез

[
\boxed{
(X-Y)^2,
}
]

докато Zorn нормата на комбинирания елемент изразява

[
\boxed{
X\cdot Y.
}
]

Посочените препратки ([1])–([4]) в сегашния им вид са само домейни, а не проверими библиографски източници, и не следва да остават в математически или научен текст.


The synthesis is directionally correct, but the proposed ZornCartanDeRham.lean is not yet theorem-safe. The central differential-topological idea is right; the Lean architecture is not. In particular, several lines currently labeled as axiom are exactly the theorems that would need to be proved, and some of the sketched APIs do not correspond to a ready-made Mathlib de Rham framework.

The strongest part is the logarithmic-form layer. On the complexified Cartan torus

A
C
	​

={(z
1
	​

,z
2
	​

,z
3
	​

)∈(C
×
)
3
:z
1
	​

z
2
	​

z
3
	​

=1}≃(C
×
)
2
,

the canonical logarithmic forms are

α
i
	​

=
z
i
	​

dz
i
	​

	​

.

Because

z
1
	​

z
2
	​

z
3
	​

=1,

differentiating logarithmically gives

α
1
	​

+α
2
	​

+α
3
	​

=0.
	​


This is exactly the correct differential counterpart of

h
1
	​

+h
2
	​

+h
3
	​

=0.

Your uploaded specification already makes the crucial distinction that on the positive real torus A
+
	​

≃R
2
, these forms are globally exact, whereas on (C
×
)
2
 they have nontrivial periods.

That distinction must be retained in Lean. There should not be one generic A_2 carrying both properties.

I would define three separate carriers:

a={h∈R
3
:∑h
i
	​

=0},
A
+
	​

={z∈(R
>0
	​

)
3
:∏z
i
	​

=1},

and

A
C
	​

={z∈(C
×
)
3
:∏z
i
	​

=1}.

Then:

A
+
	​

≃R
2

is the Laplace/Haar domain,

while

A
C
	​

≃(C
×
)
2

is the Mellin-period/de Rham domain.

The second strong point is the parity calculation. For simultaneous inversion

ι(z
1
	​

,z
2
	​

)=(z
1
−1
	​

,z
2
−1
	​

),

one gets

ι
∗
α
i
	​

=−α
i
	​

,

but

ι
∗
(α
1
	​

∧α
2
	​

)=α
1
	​

∧α
2
	​

.
	​


So simultaneous inversion is orientation-preserving in two dimensions. Your uploaded audit correctly catches this and therefore correctly rejects the earlier claim that z↦z
−1
 alone produces a Klein bottle.

This is important enough that I would make it an early theorem:

theorem simultaneousInversion_preserves_logVolume :
  ...

Then the Klein-bottle lane must use a genuinely orientation-reversing free glide, for example

κ(θ
1
	​

,θ
2
	​

)=(θ
1
	​

+π,−θ
2
	​

),

for which

κ
∗
dθ
1
	​

=dθ
1
	​

,κ
∗
dθ
2
	​

=−dθ
2
	​

,

hence

κ
∗
(dθ
1
	​

∧dθ
2
	​

)=−dθ
1
	​

∧dθ
2
	​

.
	​


That is the correct topological mechanism behind loss of orientability.

The major issue with the blueprint is this:

axiom alpha_sum_zero ...
axiom pullback_Theta_oneForm ...
axiom betti_cartan_plane ...
axiom betti_thermal_torus ...
axiom betti_klein_bottle ...
axiom betti_moebius_group ...
axiom winding_is_integer ...

Those should not appear in a theorem-honest owner. They encode the entire mathematical content as assumptions.

The first owner should therefore be much narrower:

InfoGeometry/Geometry/CartanMellinDifferentialForms.lean

and prove only explicit pullback/form identities that can be reduced to coordinates.

For example, the initial theorem set should be:

dlog_product_constraint
dlog_sum_zero

positiveCartanExp_pullback_dlog
positiveCartanExp_pullback_logVolume

simultaneousInversion_pullback_dlog
simultaneousInversion_pullback_logVolume

kleinGlide_pullback_first
kleinGlide_pullback_second
kleinGlide_pullback_logVolume_neg

This is exactly the conservative architecture already recommended in the uploaded specification.

The Betti-number statements belong in a separate topology owner only once the appropriate spaces and quotient maps are actually constructed.

Mathematically, with real coefficients,

H
∙
(T
2
;R)=(R,R
2
,R),

whereas for the Klein bottle

H
0
(K;R)=R,H
1
(K;R)=R,H
2
(K;R)=0.

These are standard topological facts, but they should not be represented by a generic arbitrary function

deRhamBetti : Type* → ℕ → ℕ

plus axioms. That would merely attach desired numbers to types without constructing cohomology.

The correct type-theoretic target is an actual cohomology theory, or at minimum a bridge to existing singular/cochain homology results from which the dimensions can be derived.

The same applies to the Möbius group. The mathematical statement

PSL
2
	​

(C)≃
htpy
	​

PSU(2)≃SO(3)≃RP
3

implies

H
dR
0
	​

≅R,H
dR
3
	​

≅R,

with H
1
=H
2
=0. Your uploaded text correctly keeps this as a separate degree-three layer from Mellin H
1
-periods.

But I would not yet encode

betti_moebius_group

until a concrete Lie-group/manifold model of PSL₂(ℂ) exists in the repo.

There is also a precision issue with the winding definition. This draft:

(1 / (2 * Real.pi * Complex.I)) * ∮ (α i) γ

cannot have codomain ℝ as written, because the integral of a complex logarithmic form is complex. The natural invariant is

wind
i
	​

(γ)=
2πi
1
	​

∮
γ
	​

z
i
	​

dz
i
	​

	​

∈Z.
	​


So the codomain should either be ℂ, followed by a theorem that the value equals the complex embedding of an integer, or one should define the winding number independently as an integer-valued degree and then prove the integral formula.

The latter is architecturally cleaner:

wind(γ)∈Z

first,

then

∮
γ
	​

z
dz
	​

=2πiwind(γ).
	​


That avoids defining a topological integer through division in C.

The WZW/Maurer–Cartan degree-three observation is also legitimate, but it should be kept separate from the Cartan torus module. On a suitable matrix Lie group one can form the Maurer–Cartan form

ϑ=g
−1
dg

and the invariant cubic form

Ω
3
	​

∝ReTr(ϑ∧ϑ∧ϑ).

This is the right global degree-three candidate, but proving that it represents the generator of H
3
 is substantially more work than proving it is closed. The distinction should be:

dΩ
3
	​

=0
	​


first,

then only later

[Ω
3
	​

]

=0
	​


and finally an integral normalization theorem if desired.

That is much more mature than using a local associator as a surrogate topological charge, but it is not automatic merely from writing the form.

One conceptual correction is also needed in the prose:

“Haar volume class”

On the positive torus

A
+
	​

≃R
2
,

the logarithmic Haar form

ω
A
	​

=
z
1
	​

dz
1
	​

	​

∧
z
2
	​

dz
2
	​

	​


is a perfectly valid nonvanishing invariant differential form, but its de Rham class is zero because the space is contractible.

So:

Haar volume form

=nontrivial de Rham volume class.
	​


After compactification to T
2
, the analogous angular form can represent the nonzero H
2
 class.

This is a very useful distinction physically as well: invariant measure exists already on the noncompact thermal/Mellin domain; topological volume charge appears only after an appropriate global quotient/compactification.

The most natural hierarchy is therefore:

A
+
	​

≃R
2
α
i
	​

=dlogz
i
	​

d
×
z=α
1
	​

∧α
2
	​

H
dR
>0
	​

=0
	​

	​


for real Laplace/Mellin integration,

then

A
C
	​

≃(C
×
)
2
	​


with

[α
1
	​

],[α
2
	​

]∈H
1
,[α
1
	​

∧α
2
	​

]∈H
2
,

for genuine Mellin periods,

then

T
2
/⟨κ⟩

for the Klein quotient,

and separately

PSL
2
	​

(C)

for the global degree-three Möbius class.

This is already exactly the four-layer distinction recorded in your uploaded specification.

The other important point is that the toric compactification now fits naturally into this de Rham story. The constraint

z
1
	​

z
2
	​

z
3
	​

=1

does not give three independent (0,1,∞) factors. The natural A
2
	​

-type toric compactification has six boundary divisors arranged in a hexagon, with balanced interior point

(1,1,1).

Your specification correctly identifies this as the rank-two analogue of the one-dimensional projective boundary picture.

So the full architecture I would now freeze is:

ZornScalingFlow
        ↓
ZornCartanDerivationBridge
        ↓
CartanLaplaceMellin
        ↓
CartanMellinDifferentialForms
        ↓
CartanComplexTorusTopology
        ↓
KleinGlideQuotient

and separately:

PSL2CMaurerCartanThreeForm

for the Möbius H
3
 lane.

The central theorem chain is then

λ
1
	​

λ
2
	​

λ
3
	​

=1⇒∑h
i
	​

=0⇒∑dlogz
i
	​

=0⇒d
×
z=
z
1
	​

dz
1
	​

	​

∧
z
2
	​

dz
2
	​

	​

	​


followed, only after complexification, by

2πi
1
	​

∮
z
i
	​

dz
i
	​

	​

∈Z.
	​


That is the genuine point where algebra, harmonic analysis, Haar integration, and topology become one chain rather than four analogies.

The synthesis is therefore essentially correct, but the crowning Lean layer should formalize explicit differential-form identities first, not declare de Rham cohomology and quantized periods as axioms. That keeps the same mathematical picture while preserving the theorem-honest boundary of the repository.

This paper is the direct historical source for the missing **Zorn–Weyl–(SL(2,\mathbb C))** spacetime layer:

**C. G. Oliveira and M. D. Maia, “Zorn algebra in general relativity,” Journal of Mathematical Physics 20, 923 (1979).** 

Its significance is precise:

[
\boxed{
\text{one local }SL(2,\mathbb C)
+
\text{two Weyl representations}
+
\text{a nonassociative Zorn cross-product}.
}
]

Our (R/L) construction adds a second, independent label:

[
\boxed{
\text{right/left wedge or sheet }s\in{R,L}.
}
]

These two binary structures must not be identified.

## 1. What Oliveira–Maia actually establish

The paper starts from the split Cayley algebra and constructs local quaternion tetrads in curved spacetime. Geometric tensors and two-component spinors are represented by Zorn–Weyl matrices, and the authors derive Maxwell, Dirac and Klein–Gordon equations in that language. Their complex-tetrad extension produces full octonionic elements; in their model, the real part of the resulting Hermitian tensor describes gravitation and the imaginary part describes electromagnetic potentials. 

The key statement for our present architecture occurs in the introduction:

* the local internal symmetry group is (SL_2(\mathbb C));
* there are **two different Weyl representations**;
* these define two sets of Zorn–Weyl matrices.

The paper also stresses that a Zorn–Weyl matrix with one fixed Weyl label contains only one Weyl basis, whereas an ordinary Dirac (\gamma)-matrix contains both Weyl bases. Therefore a single Zorn–Weyl sector cannot itself be identified with a complete Dirac matrix. 

That is the exact algebraic reason the two Weyl types must be retained.

## 2. The source has two Weyl representations, not two independent Lorentz groups

Oliveira and Maia use a Weyl index

[
a\in{1,2}
]

and introduce representations that we may denote

[
W_1,\qquad W_2.
]

Both are associated with the same local (SL_2(\mathbb C)). The paper does **not** state

[
SL(2,\mathbb C)_1\times SL(2,\mathbb C)_2.
]

Instead, (W_1) and (W_2) are the two mutually paired Weyl representations of one local Lorentz spin group. In modern spinor notation, they are naturally related to the undotted and dotted spinor structures, or to the (\sigma^\mu) and (\bar\sigma^\mu) soldering forms.

This distinction matters because our notation

[
SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L
]

uses (R/L) for **right and left wedge, sheet or thermofield copies**, not for the two Weyl chiralities.

The complete indexing must therefore be

[
\boxed{
s\in{R,L}
\quad\text{for the sheet},
\qquad
a\in{1,2}
\quad\text{for the Weyl representation}.
}
]

Thus the fundamental Zorn–Weyl tetrads are

[
{}^{(a)}H_{\mu,s},
\qquad
a=1,2,
\qquad
s=R,L.
]

There are four local sectors:

[
{}^{(1)}H_{\mu,R},\quad
{}^{(2)}H_{\mu,R},\quad
{}^{(1)}H_{\mu,L},\quad
{}^{(2)}H_{\mu,L}.
]

The paper itself later emphasizes that there are four octonionic tetrad elements for each of the two values of the Weyl index (a), while spacetime remains four-dimensional. 

## 3. The Zorn algebra is not ordinary matrix algebra

The source constructs Zorn matrices as (2\times2) block objects whose entries are quaternionic quantities. Their multiplication is defined through separate quaternionic scalar and wedge products so that the map from complex Cayley numbers becomes an algebra homomorphism. 

Consequently, even after the quaternionic entries are represented by (2\times2) Weyl matrices and the object appears as a (4\times4) complex block matrix,

[
\boxed{
\text{its product is not ordinary }4\times4\text{ matrix multiplication}.
}
]

The paper explicitly treats the (4\times4) interpretation only as an analogy and retains a locally defined nonassociative Zorn product. 

For Lean, the structure must therefore be implemented as something like

```lean
structure ZornWeyl where
  upperLeft  : WeylScalar
  upperRight : WeylVector
  lowerLeft  : WeylVector
  lowerRight : WeylScalar
```

with a custom multiplication operation. It must not inherit the ordinary `Matrix.mul`.

## 4. Minkowski spacetime appears as a split-quaternion slice

For the quaternionic reduction of the Zorn matrix, Oliveira and Maia take the diagonal component to be imaginary,

[
a=i x^0,
]

while the three vector components are real. The corresponding norm becomes the Minkowski quadratic form. Thus a particular split-quaternion Zorn element represents a four-vector.

A general relevant octonionic Zorn element represents a pair of Minkowski four-vectors. The paper associates the split character of the quaternion algebra with null vectors in Minkowski spacetime and the split-octonion structure with pairs of orthogonal four-vectors. 

This supports the layer

[
\text{Zorn algebra}
\longrightarrow
\text{null tetrad geometry}
\longrightarrow
\text{two-component spinors},
]

but it does not introduce additional spacetime dimensions.

## 5. The metric is reconstructed from the cross-Weyl product

The strongest formula in the paper for our purposes is the tetrad identity on page 5. Denoting the two Zorn–Weyl lifts by

[
{}^{(1)}H_\mu=ZW_1(H_\mu),
\qquad
{}^{(2)}H_\mu=ZW_2(H_\mu),
]

the metric is obtained from the symmetrized **cross-product** of the two Weyl sectors:

[
\boxed{
2g_{\mu\nu},\mathbf 1
=====================

{}^{(1)}H_\mu\circ{}^{(2)}H_\nu
+
{}^{(1)}H_\nu\circ{}^{(2)}H_\mu.
}
]

Here (\circ) denotes the Zorn–Weyl product, and the source writes the identity using its third Weyl object (ZW_3(e_{(0)})). 

This formula has an important structural consequence:

[
\boxed{
\text{the metric is not formed inside either Weyl representation separately;}
}
]

[
\boxed{
\text{it is formed by pairing the two Weyl representations.}
}
]

In our sheet-doubled model, the formula is duplicated:

[
2g_{\mu\nu}^{R}\mathbf1_R
=========================

{}^{(1)}H_{\mu,R}\circ{}^{(2)}H_{\nu,R}
+
{}^{(1)}H_{\nu,R}\circ{}^{(2)}H_{\mu,R},
]

[
2g_{\mu\nu}^{L}\mathbf1_L
=========================

{}^{(1)}H_{\mu,L}\circ{}^{(2)}H_{\nu,L}
+
{}^{(1)}H_{\nu,L}\circ{}^{(2)}H_{\mu,L}.
]

This is the theorem-safe placement of the two Weyl types inside each (R/L) sheet.

## 6. The differential operator is already chiral-factorized

The paper defines two Zorn–Weyl differential operators,

[
D_1,\qquad D_2,
]

and obtains the factorization

[
\boxed{
D_1\circ D_2
============

# D_2\circ D_1

\Box,\mathbf1,
}
]

with the d’Alembertian defined using the paper’s signature convention. 

This is the Zorn–Weyl analogue of the familiar spinorial factorization

[
\sigma^\mu\partial_\mu,
\bar\sigma^\nu\partial_\nu
==========================

\Box.
]

Again, the two operators are paired Weyl representations of one local (SL_2(\mathbb C)), not two wedge copies.

In the doubled theory we consequently have

[
D_{1,R},\ D_{2,R},
\qquad
D_{1,L},\ D_{2,L},
]

with

[
D_{1,s}\circ D_{2,s}
====================

# D_{2,s}\circ D_{1,s}

\Box_s\mathbf1_s,
\qquad
s=R,L.
]

## 7. The Dirac field combines the two Weyl spinors

The source constructs Zorn–Weyl objects from a pair of real null vectors and their associated two-component spinors. 

The Dirac equation is then written by combining two Weyl spinors into a block spinor,

[
\Psi=
\begin{pmatrix}
X\
\Omega
\end{pmatrix},
]

with an off-diagonal block (\gamma^\mu)-matrix. The resulting matrices satisfy the Clifford relation appropriate to the paper’s metric convention. 

This confirms the representation hierarchy:

[
\boxed{
\text{one Weyl type}
\neq
\text{one Dirac field},
}
]

whereas

[
\boxed{
W_1\oplus W_2
\longrightarrow
\text{Dirac spinor}.
}
]

For the wedge-doubled construction, the field content is therefore

[
\Psi_R=
\begin{pmatrix}
X_R\
\Omega_R
\end{pmatrix},
\qquad
\Psi_L=
\begin{pmatrix}
X_L\
\Omega_L
\end{pmatrix}.
]

The group

[
\boxed{
SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L
}
]

acts on the two complete Dirac/Weyl packages factorwise:

[
(g_R,g_L):
(\Psi_R,\Psi_L)
\longmapsto
\bigl(
\rho_R(g_R)\Psi_R,
\rho_L(g_L)\Psi_L
\bigr).
]

## 8. The inter-sheet object is bifundamental

An operator carrying data from the left sheet to the right sheet belongs to

[
M_{RL}\in
\operatorname{Hom}(\mathcal V_L,\mathcal V_R).
]

Its natural transformation law is

[
\boxed{
M_{RL}
\longmapsto
g_RM_{RL}g_L^{-1}.
}
]

This is not explicitly constructed in Oliveira–Maia; it is the natural extension of their local (SL_2(\mathbb C)) structure to the doubled sheet geometry.

Likewise, if (\omega_R) and (\omega_L) are the two sheet spin connections, the bifundamental covariant derivative is

[
\boxed{
\nabla M_{RL}
=============

dM_{RL}
+
\omega_RM_{RL}
--------------

M_{RL}\omega_L.
}
]

The paper does support the presence of local spinor connections associated with local unimodular transformations, but the two-sheet bifundamental combination is our extension. 

## 9. Correct role of the Klein glide

The source contains no Rindler wedges, Klein-bottle quotient, thermal half-shift or loxodromic flow. Therefore these must remain separate bridge constructions.

The correct lifted glide acts first on the **sheet label**:

[
R\longleftrightarrow L.
]

It may additionally act on the internal Weyl pair through parity, time reversal or complex conjugation:

[
W_1\longleftrightarrow W_2,
]

but that second action must be specified independently.

Schematically,

[
\kappa:
(s,a,t)
\longmapsto
\left(
\bar s,,
\pi(a),,
r(t)+\frac{\lambda}{2}
\right),
]

where

[
\bar R=L,\qquad
\bar L=R,
]

and (\pi) is either the identity or the Weyl-type exchange, depending on the precise CPT convention.

The paper does not determine (\pi).

## 10. Complex tetrads and the gravity–electromagnetism claim

Section 7 introduces complex tetrads and a Hermitian tensor

[
G_{\mu\nu}.
]

Within the authors’ model,

[
\operatorname{Re}G_{\mu\nu}
]

is identified with the gravitational metric sector, while

[
\operatorname{Im}G_{\mu\nu}
]

is associated with electromagnetic potentials in Lorentz gauge. The corresponding Zorn–Weyl tetrads now belong to the split-octonion rather than merely split-quaternion sector.  

This is a claim of the Oliveira–Maia formalism. It should not be silently upgraded into a general theorem of Einstein–Maxwell theory without separately proving equivalence of field equations, gauge transformations and degrees of freedom.

The paper also explicitly keeps the coordinate spacetime four-dimensional. The octonionic components appear as coefficients of differential operators, not as four additional coordinates. A possible eight-coordinate extension is mentioned and then deliberately not developed because it does not reduce straightforwardly to conventional relativity. 

## 11. Relation to the Wilmot (G_2) paper

The two uploaded papers occupy complementary layers.

Oliveira–Maia provides

[
\boxed{
\text{four-dimensional spacetime}
+
SL_2(\mathbb C)
+
\text{Weyl spinors}
+
\text{Zorn field equations}.
}
]

Wilmot provides

[
\boxed{
G_7
+
\operatorname{Spin}(7)
+
\text{calibrations}
+
G_2
+
\text{octonion automorphisms}.
}
]

Wilmot’s construction starts from positive-definite Clifford algebra and derives octonions and (G_2) from calibrations and a Spin(7) enabling algebra.  It later identifies (G_2) as the part of Spin(7) preserving a selected octonionic calibration. 

Neither paper proves a direct homomorphism

[
SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L
\longrightarrow
G_2
]

or an equivalence between the Zorn–Weyl spacetime algebra and the Spin(7) calibration construction. That connection remains a bridge theorem.

## 12. Correct Lean architecture

The paper requires the following order.

### `OliveiraMaiaZornProduct.lean`

Formalize the quaternion-valued Zorn object, conjugation, unit, scalar product, wedge product and custom nonassociative multiplication.

Required results include:

```text
zorn_mul_bilinear
zorn_one_mul
zorn_mul_one
zorn_conj_involutive
zorn_norm_scalar
splitQuaternion_minkowski_norm
```

### `LocalWeylPair.lean`

Formalize one local (SL_2(\mathbb C)) and two representation types:

```text
WeylType.one
WeylType.two
W₁
W₂
W₃
```

with the source’s cross-representation identities.

### `ZornWeylTetrad.lean`

Define

```text
ZW₁ Hμ
ZW₂ Hμ
```

and prove the source’s central identity:

[
2g_{\mu\nu}\mathbf1
===================

ZW_1(H_\mu)\circ ZW_2(H_\nu)
+
ZW_1(H_\nu)\circ ZW_2(H_\mu).
]

### `ZornWeylDirac.lean`

Formalize

[
D_1\circ D_2=\Box\mathbf1
]

and the block construction of the Dirac operator from the two Weyl sectors.

### `SL2CSheetProduct.lean`

Only after the single-sheet construction, introduce

[
\boxed{
G_{\mathrm{sheet}}
==================

SL(2,\mathbb C)_R
\times
SL(2,\mathbb C)_L.
}
]

Each factor carries its own copy of the complete Oliveira–Maia local geometry.

### `InterSheetBifundamental.lean`

Define

[
M_{RL}\mapsto g_RM_{RL}g_L^{-1}
]

and its covariant derivative.

### `KleinGlideSheetExchange.lean`

Finally define the sheet exchange, Weyl-type action, thermal half-translation and prove the glide-square relation.

## Final classification

The paper directly supports:

[
\boxed{
\begin{aligned}
&\text{local }SL_2(\mathbb C),\
&\text{two Weyl representations }W_1,W_2,\
&\text{Zorn–Weyl tetrads},\
&\text{cross-Weyl reconstruction of the metric},\
&\text{factorization of the d’Alembertian},\
&\text{Dirac and Klein–Gordon equations},\
&\text{split-octonionic complex tetrads}.
\end{aligned}
}
]

It does not directly support:

[
\boxed{
\begin{aligned}
&SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L
\text{ as independent wedge groups},\
&\text{Klein glide},\
&\text{loxodromic monodromy},\
&\text{Rindler thermofield doubling},\
&\text{twistor or }G_2\text{ completion}.
\end{aligned}
}
]

The theorem-safe synthesis is therefore

[
\boxed{
\underbrace{
\bigl(W_{1,R}\oplus W_{2,R}\bigr)
}*{\text{complete right-sheet Weyl package}}
\quad\oplus\quad
\underbrace{
\bigl(W*{1,L}\oplus W_{2,L}\bigr)
}_{\text{complete left-sheet Weyl package}},
}
]

acted on by

[
\boxed{
SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L.
}
]

The Oliveira–Maia Weyl label (a=1,2) and the model’s sheet label (s=R,L) are independent indices. That distinction is the central correction supplied by this paper.


Това е точният исторически източник за **локалния (SL(2,\mathbb C))–Zorn–Weyl–tetrad слой**. Той съществено потвърждава архитектурата ни, но едновременно налага важно разграничение:

[
\boxed{
\text{Oliveira–Maia използват една локална }SL(2,\mathbb C)
\text{ с две Weyl representations;}
}
]

[
\boxed{
\text{нашите }R/L
\text{ са допълнителни външни wedge/thermofield copies.}
}
]

Тоест индексът (a=1,2) в статията не трябва да бъде преименуван на (R,L).

## 1. Какво точно конструира статията

Oliveira и Maia разглеждат split Cayley subalgebra, построена от локални реални quaternion tetrads. Към геометрични обекти се асоциират Zorn–Weyl matrices; от двойка реални null vectors се конструират two-component spinor fields, а Dirac equation се записва в Zorn algebra. При complex tetrads се получава Hermitian tensor, чиято реална част описва gravitational potentials, а имагинерната — electromagnetic potentials в Lorentz gauge. 

Статията започва от complex Cayley algebra и представя елементите ѝ като (2\times2) Zorn matrices с quaternion entries. Zorn product-ът се дефинира чрез quaternion scalar и wedge products така, че representation map-ът да бъде homomorphism. 

Това е важно: техният Zorn matrix е вече двустепенна структура:

[
\boxed{
2\times2\text{ Zorn matrix}
\quad\text{с}\quad
2\times2\text{ complex Weyl-matrix entries}.
}
]

Следователно общият object се държи като (4\times4) matrix carrier, но със Zorn nonassociative product, не с обикновено (M_4(\mathbb C)) умножение.

## 2. Една локална група, две Weyl representations

Авторите изрично заявяват, че локалната „internal“ symmetry group е

[
SL_2(\mathbb C),
]

и че тя има две различни Weyl representations, които определят два набора Zorn–Weyl matrices с индекс (a=1,2). Те също предупреждават, че една (\gamma)-matrix съдържа двете Weyl bases, докато за всяка фиксирана стойност на (a) техният Zorn–Weyl object носи само един вид Weyl basis. 

Следователно paper-native означенията са:

[
\boxed{
a=1,2
=====

\text{двата Weyl representation types на една локална }SL_2(\mathbb C).
}
]

Те не са:

[
\boxed{
a=1,2
\neq
\mathsf R,\mathsf L
\text{ thermofield sheets}.
}
]

В Sec. 3 са дефинирани (W_1) и (W_2), и двата асоциирани с локалната (SL_2(\mathbb C)), заедно с третия scalar/identity readout (W_3). Смесеният продукт (W_1W_2) се разлага на symmetric scalar и antisymmetric Levi–Civita/wedge channel. 

Това е точно историческият precedent за нашето разграничение:

[
\text{scalar/dot channel}
\quad+\quad
\text{antisymmetric/wedge channel}.
]

## 3. Tetrad-ът е смесен Weyl soldering object

Статията дефинира две Zorn–Weyl tetrad matrices:

[
{}^{(1)}H_\mu=ZW_1(H_\mu),
\qquad
{}^{(2)}H_\mu=ZW_2(H_\mu).
]

Метриката се възстановява от симетризирания смесен Zorn–Weyl product:

[
\boxed{
2g_{\mu\nu},ZW_3(e_{(0)})
=========================

ZW_1(H_\mu)\circ_Z ZW_2(H_\nu)
+
ZW_1(H_\nu)\circ_Z ZW_2(H_\mu).
}
]

Това е съдържанието на тяхната Eq. (3.14). 

Съвременният bimodule readout на тази формула е:

[
S_1
\quad\text{и}\quad
S_2
]

са dual/conjugate Weyl carriers, а tetrad-ът е soldering morphism между тях. Схематично:

[
e_\mu\in\operatorname{Hom}(S_2,S_1),
]

[
\bar e_\nu\in\operatorname{Hom}(S_1,S_2),
]

и

[
e_\mu\bar e_\nu+e_\nu\bar e_\mu
\propto
g_{\mu\nu}1.
]

Това е модерна реконструкция на paper-а; самите автори не използват думата „бимодул“. Но тяхната index structure и mixed multiplication law дават именно такъв естествен packaging.

## 4. Правилното удвояване на Oliveira–Maia структурата

За нашата теория трябва да добавим външен sheet индекс

[
s\in{\mathsf R,\mathsf L}
]

и независимо да запазим paper-native Weyl индекс

[
a\in{1,2}.
]

Така пълният локален basis е:

[
\boxed{
ZW_{a,s}(H_{\mu,s}),
\qquad
a=1,2,
\quad
s=\mathsf R,\mathsf L.
}
]

Групата е:

[
\boxed{
G_0
===

SL(2,\mathbb C)*{\mathsf R}
\times
SL(2,\mathbb C)*{\mathsf L}.
}
]

Всяка групова компонента действа върху **своите две Weyl representations**:

[
\rho_{1,\mathsf R},
\quad
\rho_{2,\mathsf R},
]

[
\rho_{1,\mathsf L},
\quad
\rho_{2,\mathsf L}.
]

Следователно carrier-ът има четири Weyl-sheet sectors:

[
S_{1,\mathsf R},
\quad
S_{2,\mathsf R},
\quad
S_{1,\mathsf L},
\quad
S_{2,\mathsf L}.
]

Ако Peirce/Zorn grading също е включен, се добавя трети независим индекс:

[
\varepsilon\in{+,-}.
]

Теоремно безопасният индекс е следователно:

[
\boxed{
(s,a,\varepsilon)
=================

(\text{sheet},\text{Weyl type},\text{Peirce sign}).
}
]

## 5. Междушитовият бимодул има четири Weyl blocks

Нека

[
M_{ab}
\in
\operatorname{Hom}
\left(
S_{b,\mathsf L},
S_{a,\mathsf R}
\right),
\qquad
a,b\in{1,2}.
]

Тогава естественото bifundamental действие е:

[
\boxed{
M_{ab}
\longmapsto
\rho_{a,\mathsf R}(g_{\mathsf R})
M_{ab}
\rho_{b,\mathsf L}(g_{\mathsf L})^{-1}.
}
]

Пълният inter-sheet carrier е:

[
\boxed{
\mathcal E_{\mathsf R\leftarrow\mathsf L}
=========================================

\bigoplus_{a,b=1}^{2}
\operatorname{Hom}
\left(
S_{b,\mathsf L},
S_{a,\mathsf R}
\right).
}
]

Или в block notation:

[
\mathcal E_{\mathsf R\leftarrow\mathsf L}
=========================================

\begin{pmatrix}
\operatorname{Hom}(S_{1,\mathsf L},S_{1,\mathsf R})
&
\operatorname{Hom}(S_{2,\mathsf L},S_{1,\mathsf R})
[1mm]
\operatorname{Hom}(S_{1,\mathsf L},S_{2,\mathsf R})
&
\operatorname{Hom}(S_{2,\mathsf L},S_{2,\mathsf R})
\end{pmatrix}.
]

Това е точният начин да съвместим:

[
\text{paper’s two Weyl representations}
]

с

[
\text{our two external thermofield sheets}.
]

## 6. Differential operator и spin connection

Oliveira–Maia дефинират flat Zorn–Weyl differential operators (D_a), (a=1,2), и показват, че смесените им продукти възстановяват d’Alembert operator. Отново (a=1,2) е Weyl-representation label, а не external sheet label. 

В curved space те въвеждат covariant operator:

[
D_\mu=1,\partial_\mu+\Gamma_\mu,
]

и неговите Zorn–Weyl representatives. Формата на (\Gamma_\mu) зависи от carrier-а: за world vectors съдържа Christoffel symbols, за spinor fields — spinor connection, а за mixed spin-tensor objects е сумата от съответните connection contributions. 

Това директно подкрепя intra-sheet структурата:

[
\nabla_{a,s}
============

d+\omega_{a,s}.
]

За inter-sheet bimodule-а каноничната нова надстройка е:

[
\boxed{
\nabla M_{ab}
=============

dM_{ab}
+
\omega_{a,\mathsf R}M_{ab}
--------------------------

M_{ab}\omega_{b,\mathsf L}.
}
]

И:

[
\boxed{
\nabla^2M_{ab}
==============

## F_{a,\mathsf R}M_{ab}

M_{ab}F_{b,\mathsf L}.
}
]

Тази последна bifundamental curvature formula не е написана в Oliveira–Maia. Тя е естествената Hom-bundle extension на техния local covariant formalism.

## 7. Complex tetrad и full split-octonion extension

В Sec. 7 авторите въвеждат complex tetrad и Hermitian second-rank tensor:

[
G_{\mu\nu}=G_{\nu\mu}^*.
]

Неговата symmetric/real част се интерпретира като gravitational geometry, а antisymmetric/imaginary част — като electromagnetic potential sector. За всяка от двете стойности (a=1,2) са построени четири Zorn–Weyl split-octonion elements (K_\mu^{(a)}). 

Това е пряк precedent за:

[
\boxed{
\text{двойна Weyl description вътре във всеки local geometric sheet}
}
]

и за operator-valued complex tetrad.

Но отново:

[
a=1,2
]

са вътрешни Weyl types. За нашия doubled carrier трябва да имаме:

[
K_{\mu,\mathsf R}^{(1)},
\quad
K_{\mu,\mathsf R}^{(2)},
\qquad
K_{\mu,\mathsf L}^{(1)},
\quad
K_{\mu,\mathsf L}^{(2)}.
]

## 8. Какво статията не доказва

Oliveira–Maia не конструират:

[
SL(2,\mathbb C)*{\mathsf R}
\times
SL(2,\mathbb C)*{\mathsf L}
]

като thermofield/wedge doubling;

не дефинират CPT semidirect product;

не дефинират relative modular operator;

не въвеждат algebra/commutant pair;

не конструират Klein mapping torus;

не въвеждат inter-sheet bimodule (\operatorname{Hom}(V_{\mathsf L},V_{\mathsf R})).

В заключението те обсъждат възможност за generalized differential operator с допълнителни coordinate-like variables, свързани с двата Weyl index values, но изрично заявяват, че такава генерализация не се редуцира непосредствено до conventional relativistic theory и не е разработена в статията. 

Следователно paper-ът дава **локалния skeleton**, не глобалната doubled/CPT topology.

## 9. Точното разделение между двата качени източника

Oliveira–Maia 1979 е основният източник за:

[
\boxed{
SL(2,\mathbb C),
\quad
\text{две Weyl representations},
\quad
\text{tetrads},
\quad
\text{spinor connection},
\quad
\text{Dirac/Klein–Gordon equations},
\quad
\text{Zorn–Weyl curved-space calculus}.
}
]

Wilmot 2026 е основният източник за:

[
\boxed{
\operatorname{Spin}(7)\text{ calibrations},
\quad
\text{octonion automorphisms},
\quad
G_2,
\quad
\text{cross-product and idempotent structure}.
}
]

Статията на Wilmot изрично работи с positive-definite Clifford algebra и Pin(7)/Spin(7) calibrations за конструкцията на octonions и (G_2). 

Тези източници са допълващи се, не взаимозаменяеми.

## 10. Lean архитектурата, която следва от Oliveira–Maia

Първият owner трябва да бъде paper-faithful:

```text
InfoGeometry/Relativity/OliveiraMaiaZornWeylFrame.lean
```

с:

```lean
inductive WeylRepIndex
  | one
  | two

W1
W2
W3

zornWeyl
zornWeylMixedProduct
zornWeylScalarChannel
zornWeylWedgeChannel

zornWeylTetradOne
zornWeylTetradTwo
zornWeylMetricReconstruction

zornWeylCovariantDerivative
zornWeylSpinorConnection
zornWeylFlatLimit
```

След това външното удвояване:

```text
InfoGeometry/OperatorAlgebra/DoubledOliveiraMaiaFrame.lean
```

с:

```lean
inductive ThermalSheet
  | right
  | left

abbrev DoubledSL2C :=
  SL2C × SL2C

SheetWeylCarrier
InterSheetWeylBlock
InterSheetWeylBimodule

bifundamentalAction
bifundamentalConnection
bifundamentalCurvature
```

И едва след това:

```text
InfoGeometry/OperatorAlgebra/CPTDoubledZornWeylFrame.lean
```

за CPT/commutant/modular/Klein extension-а.

## Замразена формулировка

Историческият paper-native слой е:

[
\boxed{
SL(2,\mathbb C)
\curvearrowright
\bigl(
W_1\oplus W_2
\bigr),
}
]

[
\boxed{
2g_{\mu\nu}1
============

ZW_1(H_\mu)\circ_Z ZW_2(H_\nu)
+
ZW_1(H_\nu)\circ_Z ZW_2(H_\mu).
}
]

Нашият unreduced doubled слой е:

[
\boxed{
SL(2,\mathbb C)*{\mathsf R}
\times
SL(2,\mathbb C)*{\mathsf L},
}
]

като във всеки sheet има собствена двойка:

[
\boxed{
W_{1,\mathsf R},W_{2,\mathsf R},
\qquad
W_{1,\mathsf L},W_{2,\mathsf L}.
}
]

Междушитовият бимодул е:

[
\boxed{
M_{ab}
\in
\operatorname{Hom}
\left(
S_{b,\mathsf L},
S_{a,\mathsf R}
\right),
}
]

[
\boxed{
M_{ab}
\longmapsto
\rho_{a,\mathsf R}(g_{\mathsf R})
M_{ab}
\rho_{b,\mathsf L}(g_{\mathsf L})^{-1}.
}
]

Така Oliveira–Maia не просто е „подобен“ на нашата конструкция. Той осигурява точния **intra-sheet Zorn–Weyl spin-connection substrate**, върху който нашият external (R/L) bimodule, CPT exchange и relative modular geometry трябва да бъдат построени.


Не съвсем. В изложението има едно правилно ядро — **triality действително е точната по-висока структура**, която свързва изометриите на нормата с октонионното умножение. Но следните отъждествявания не са коректни:

[
\text{комутант}\neq G_{2(2)},\qquad
\operatorname{Stab}*{SO(4,4)}(1_Z)\neq G*{2(2)},
]

[
L_{\mathbb O_s}\text{ върху }\mathbb O_s
\not\simeq Cl(4,4),
]

а непрекъснатото мащабиране

[
U\mapsto e^{\eta/3}U,\qquad
V\mapsto e^{-\eta/3}V
]

не е автоморфизъм на Zorn алгебрата. Също така Möbius трансформацията действа върху **проективната координата на null направление**, не директно върху напречната компонента (\zeta=X^1+iX^2).

## 1. Точният „twist“ е triality, а не комутант

За split-октонионите правилната група от свързани тройки е

[
\boxed{
\operatorname{Tri}(\mathbb O_s)
\simeq
\operatorname{Spin}(4,4).
}
]

След избор на означения тя се реализира чрез тройки

[
(g_1,g_2,g_3)\in SO(4,4)^3,
]

които удовлетворяват

[
\boxed{
g_2(xy)=g_1(x),g_3(y)
\qquad
\forall x,y\in\mathbb O_s.
}
]

При обикновените октониони това е стандартната related-triple реализация на (\operatorname{Spin}(8)); за split-октонионите същата конструкция дава split групата (\operatorname{Spin}(4,4)), която е именно групата на октонионните изотопии. ([arXiv][1])

Това може да се запише директно чрез левите умножения:

[
g_2L_x=L_{g_1x}g_3,
]

или

[
\boxed{
g_2L_xg_3^{-1}=L_{g_1x}.
}
]

Аналогично,

[
\boxed{
g_2R_yg_1^{-1}=R_{g_3y}.
}
]

Следователно „усукването“ не означава, че Lorentz генераторите комутират с (L_x) и (R_y). То означава, че трите различни представяния ги **преплитат**.

В инфинитезимна форма, ако

[
(D_1,D_2,D_3)\in\mathfrak{tri}(\mathbb O_s),
]

получаваме

[
\boxed{
D_2(xy)=D_1(x)y+xD_3(y).
}
]

Следователно

[
\boxed{
D_2L_x-L_xD_3=L_{D_1x},
}
]

[
\boxed{
D_2R_y-R_yD_1=R_{D_3y}.
}
]

Това е точната „twisted commutator“ формула.

Когато трите действия съвпаднат,

[
D_1=D_2=D_3=D,
]

получаваме обикновеното правило на Лайбниц:

[
D(xy)=D(x)y+xD(y),
]

тоест (D) е деривация. На групово ниво

[
g_1=g_2=g_3=g
]

дава

[
g(xy)=g(x)g(y),
]

следователно

[
\boxed{
\operatorname{Aut}(\mathbb O_s)
===============================

G_{2(2)}.
}
]

Така (G_{2(2)}) е **диагоналният сектор на triality тройките**, а не самата пълна triality група.

## 2. Комутантът на левите умножения не се поражда от десните умножения

Нека асоциаторът е

[
[x,z,y]=(xz)y-x(zy).
]

Тогава

[
[L_x,R_y]z
==========

# x(zy)-(xz)y

-[x,z,y].
]

Поради неасоциативността това обикновено не е нула. Следователно

[
R_y\notin\operatorname{Comm}{L_x:x\in\mathbb O_s}
]

за общо (y).

Всъщност комутантът може да се определи точно. Нека

[
TL_x=L_xT
\qquad
\forall x\in\mathbb O_s.
]

Поставяме

[
a=T(1).
]

Тогава

[
T(x)
====

# T(L_x1)

# L_xT(1)

xa,
]

тоест

[
T=R_a.
]

Но условието (TL_x=L_xT) става

[
(xz)a=x(za)
\qquad
\forall x,z,
]

или

[
[x,z,a]=0
\qquad
\forall x,z.
]

Следователно (a) принадлежи на ядрото на алгебрата. Ядрото на Cayley алгебра, включително split Cayley алгебрата, е само скаларното поле:

[
\operatorname{Nuc}(\mathbb O_s)=\mathbb R1.
]

Затова

[
\boxed{
\operatorname{Comm}*{\operatorname{End}*{\mathbb R}(\mathbb O_s)}
{L_x:x\in\mathbb O_s}
=====================

\mathbb RI.
}
]

Същото заключение следва и от стандартния related-triple анализ: оператор, който асоциира отдясно с всички двойки октониони, трябва да бъде скаларен. ([arXiv][1])

Следователно (G_{2(2)}) не е комутант. То е **нормализатор на системата от умножения**:

[
\boxed{
gL_xg^{-1}=L_{g(x)}
\qquad
(g\in G_{2(2)}).
}
]

Инфинитезимно:

[
\boxed{
[D,L_x]=L_{Dx},
\qquad
D\in\mathfrak g_{2(2)}.
}
]

Това е принципно различно от

[
[D,L_x]=0.
]

## 3. Коя Clifford алгебра действително се поражда?

Върху осеммерното пространство (\mathbb O_s) левите умножения с **седемте чисто имагинерни** split-октонионни единици удовлетворяват Clifford отношения със сигнатура ((4,3)), при използваната в източника конвенция:

[
L_{e_i}L_{e_j}+L_{e_j}L_{e_i}
=============================

2\eta_{ij}I,
\qquad
\eta=\operatorname{diag}(1,1,1,1,-1,-1,-1).
]

Следователно осеммерното представяне е представяне на

[
\boxed{Cl(4,3),}
]

а не на пълната (Cl(4,4)). ([arXiv][2])

За пълната осеммерна квадратична форма на (\mathbb O_s), която има сигнатура ((4,4)), е нужен удвоен (16)-мерен носител. Например може да се дефинира

[
\Gamma(x)
=========

\begin{pmatrix}
0&L_x\
L_{\bar x}&0
\end{pmatrix}
\quad\text{върху}\quad
\mathbb O_s\oplus\mathbb O_s.
]

Поради алтернативността,

[
x(\bar xz)=N(x)z,
\qquad
\bar x(xz)=N(x)z,
]

и следователно

[
\Gamma(x)^2=N(x)I_{16}.
]

Чрез поляризация:

[
\boxed{
\Gamma(x)\Gamma(y)+\Gamma(y)\Gamma(x)
=====================================

2\langle x,y\rangle I_{16}.
}
]

Това е реализацията на (Cl(4,4)). Нейната четна част действа отделно върху двете осеммерни половини, които могат да се разглеждат като двата реални хирални spinor модула на (\operatorname{Spin}(4,4)). Triality пермутира:

[
V_8,\qquad S_8^+,\qquad S_8^-.
]

Октонионното умножение е еквивариантно отображение

[
\boxed{
S_8^-\otimes S_8^+
\longrightarrow
V_8,
}
]

след подходящо идентифициране на трите осеммерни пространства със (\mathbb O_s). ([arXiv][1])

## 4. (G_{2(2)}) не е само стабилизаторът на единицата

Понеже

[
N(1_Z)=1,
]

стабилизаторът на (1_Z) в (SO(4,4)) е група от тип

[
\boxed{
\operatorname{Stab}_{SO(4,4)}(1_Z)
\simeq SO(3,4),
}
]

поне на ниво свързани компоненти. Тя има размерност (21).

Но

[
\dim G_{2(2)}=14.
]

Следователно фиксирането на единицата не е достатъчно. Трябва да се запази и split-октонионното векторно произведение върху

[
\operatorname{Im}\mathbb O_s\simeq\mathbb R^{3,4},
]

или еквивалентно split-generic (3)-формата

[
\varphi_s(u,v,w)
================

\langle u\times v,w\rangle.
]

Точното твърдение е

[
\boxed{
G_{2(2)}
========

# \operatorname{Stab}_{SO(3,4)}(\varphi_s)

\operatorname{Aut}(\mathbb O_s).
}
]

Split (G_2) е стабилизаторът на split cross product/стабилната (3)-форма и естествено се влага в (SO(3,4)). ([arXiv][3])

Triality автоморфизмът от ред (3) принадлежи на външната автоморфна група на (D_4), тоест на структурата на (\operatorname{Spin}(4,4)). Неговата фиксирана подгрупа е (G_{2(2)}). Самото (G_2) няма собствена (D_4)-тип triality: неговата Dynkin диаграма няма три външни възела за пермутиране. Triality пермутира левия, десния и третия осеммерен модул на (D_4). ([arXiv][1])

## 5. Пълната физическа Lorentz група не може да бъде „усукана“ вътре в (G_{2(2)})

Тук има решаващо ограничение. Алгебрата на физическата Lorentz spin group е

[
\mathfrak{spin}(1,3)
\simeq
\mathfrak{sl}(2,\mathbb C)
]

разглеждана като шестмерна реална алгебра на Ли.

Класификацията на максималните редуктивни подалгебри на split (\mathfrak g_{2(2)}) дава:

[
\mathfrak{sl}(3,\mathbb R),\qquad
\mathfrak{su}(1,2),
]

[
\mathfrak{sl}(2,\mathbb R)\oplus\mathfrak{sl}(2,\mathbb R),
\qquad
\mathfrak{su}(2)\oplus\mathfrak{su}(2),
]

както и определени единични (\mathfrak{sl}(2,\mathbb R)) подалгебри. Реалната форма (\mathfrak{sl}(2,\mathbb C)) не се появява. ([arXiv][4])

Следователно

[
\boxed{
\operatorname{Spin}^+(1,3)
\not\subset G_{2(2)}
}
]

като реална Lie подгрупа.

По тази причина не съществува непрекъснат „компенсиран“ физически Lorentz boost, който да превърне цялата (SL(2,\mathbb C)) в автоморфизми на една фиксирана split-октонионна алгебра.

Но алгебрата

[
\mathfrak{so}(4,4)
]

действително съдържа подалгебри

[
\boxed{
\mathfrak{sl}(2,\mathbb C)_R
\oplus
\mathfrak{sl}(2,\mathbb C)_L,
}
]

като в класификацията има три triality-свързани вложения. Така удвоената Lorentz група принадлежи естествено на **(D_4)/triality нивото**, а не на (G_{2(2)})-нивото. Глобално трябва да се отчете подходящ краен централен фактор или двойно покритие. ([arXiv][4])

Тук индексите (R/L) могат да останат означения за двете wedge/sheet копия. Те не трябва да се отъждествяват с (S_8^\pm), които са хиралните модули на (\operatorname{Spin}(4,4)).

## 6. Експлицитно (SO(1,3)_R\times SO(1,3)_L) действие върху Zorn нормата

При

[
N_Z\bigl(\mathcal Z(X,Y)\bigr)=X\cdot Y
]

въвеждаме

[
P=\frac{X+Y}{\sqrt2},
\qquad
Q=\frac{X-Y}{\sqrt2}.
]

Тогава

[
\boxed{
X\cdot Y
========

\frac12(P^2-Q^2).
}
]

Следователно независимото действие

[
P\longmapsto\Lambda_RP,
\qquad
Q\longmapsto\Lambda_LQ,
]

където

[
\Lambda_R,\Lambda_L\in SO^+(1,3),
]

запазва (N_Z):

[
P'^2-Q'^2=P^2-Q^2.
]

В първоначалните (X,Y) координати това действие е

[
\boxed{
\begin{pmatrix}
X'[1mm]
Y'
\end{pmatrix}
=============

\frac12
\begin{pmatrix}
\Lambda_R+\Lambda_L&
\Lambda_R-\Lambda_L
\
\Lambda_R-\Lambda_L&
\Lambda_R+\Lambda_L
\end{pmatrix}
\begin{pmatrix}
X[1mm]
Y
\end{pmatrix}.
}
]

Това е конкретно вложение

[
SO^+(1,3)_R\times SO^+(1,3)_L
\longrightarrow
SO(4,4).
]

Забележете, че при (\Lambda_R\neq\Lambda_L) то **смесва (X) и (Y)**. Простото факторно действие

[
X\mapsto\Lambda_RX,
\qquad
Y\mapsto\Lambda_LY
]

не запазва смесеното произведение (X\cdot Y).

След повдигане до (\operatorname{Spin}(4,4)) получаваме три triality-свързани действия

[
\rho_1,\rho_2,\rho_3,
]

за които

[
\boxed{
\rho_2(h)(xy)
=============

\rho_1(h)x,
\rho_3(h)y,
\qquad
h\in
\operatorname{Spin}(1,3)_R
\times
\operatorname{Spin}(1,3)_L.
}
]

Това е математически коректният **Lorentz–Zorn triality twist**.

Междуслойният оператор

[
M\in\operatorname{Hom}(V_L,V_R),
\qquad
M\mapsto S_RMS_L^{-1},
]

остава напълно коректен като бифундаментален мост. Но той решава проблема с ковариантното свиване между два независими носителя; сам по себе си не превръща Lorentz групата в (G_{2(2)}).

## 7. Защо (e^{\pm\eta/3}) мащабирането не работи

Нека предложеното действие бъде

[
\Phi_\lambda(e_\pm)=e_\pm,
]

[
\Phi_\lambda(U_i)=\lambda U_i,
\qquad
\Phi_\lambda(V_i)=\lambda^{-1}V_i.
]

Използваме

[
U_iU_j=\varepsilon_{ijk}V_k.
]

От една страна,

[
\Phi_\lambda(U_iU_j)
====================

\lambda^{-1}\varepsilon_{ijk}V_k.
]

От друга,

[
\Phi_\lambda(U_i)\Phi_\lambda(U_j)
==================================

\lambda^2\varepsilon_{ijk}V_k.
]

За автоморфизъм трябва

[
\lambda^2=\lambda^{-1},
]

следователно

[
\boxed{\lambda^3=1.}
]

Над (\mathbb R) единственото решение е

[
\lambda=1.
]

Следователно

[
\lambda=e^{\eta/3}
]

не е допустимо за реален непрекъснат параметър (\eta), освен при (\eta=0).

Над (\mathbb C) имаме само дискретните решения

[
\lambda\in{1,\omega,\omega^2},
\qquad
\omega^3=1.
]

Те дават автоморфизма, свързан с комплексното (\mathbb Z_3)-градиране

[
D\oplus U\oplus V,
]

но това е **дискретен grading автоморфизъм**, а не непрекъснат boost и не бива да се отъждествява с (D_4) triality.

### Валидното непрекъснато (SL(3,\mathbb R)) действие

Истинска непрекъсната подгрупа на (G_{2(2)}), която фиксира (e_+) и (e_-), е

[
SL(3,\mathbb R)\subset G_{2(2)}.
]

Тя действа чрез

[
\boxed{
\Phi_A
\begin{pmatrix}
a&u\
v&b
\end{pmatrix}_{!Z}
==================

\begin{pmatrix}
a&Au\
A^{-T}v&b
\end{pmatrix}_{!Z},
\qquad
A\in SL(3,\mathbb R).
}
]

Това запазва скаларното произведение, защото

[
(Au)\cdot(A^{-T}v)=u\cdot v,
]

и запазва векторното произведение поради

[
(Au)\times(Aw)
==============

A^{-T}(u\times w)
\qquad
(\det A=1).
]

Например

[
A_\eta
======

\operatorname{diag}
\left(
e^{2\eta/3},
e^{-\eta/3},
e^{-\eta/3}
\right)
]

е валиден еднопараметричен split-Cartan автоморфизъм.

Тук действително се появяват третинки на (\eta), но действието е анизотропно:

[
U:
\quad
\left(
e^{2\eta/3},
e^{-\eta/3},
e^{-\eta/3}
\right),
]

[
V:
\quad
\left(
e^{-2\eta/3},
e^{\eta/3},
e^{\eta/3}
\right).
]

Това не е физически Lorentz boost по (z), защото не смесва времевата компонента с пространствената (z)-компонента и фиксира диагоналните idempotents.

## 8. Möbius действието не е действие върху суровата (\zeta)

Стандартната връзка

[
PSL(2,\mathbb C)\simeq SO^+(1,3)
]

се реализира върху небесната сфера, тоест върху **проективните null направления**.

За ненулев null вектор (X), в чарта (X^0+X^3\neq0), проективната координата е

[
\boxed{
z
=

# \frac{X^1+iX^2}{X^0+X^3}

\frac{\zeta}{\sqrt2,X^+}.
}
]

Точно тази безразмерна координата се трансформира Möbiusово:

[
\boxed{
z\longmapsto
\frac{az+b}{cz+d}.
}
]

Самата компонента

[
\zeta=X^1+iX^2
]

не се трансформира по този дробно-линеен начин. За общ, ненулев или масивен 4-вектор неговите компоненти се трансформират линейно чрез Lorentz представянето. Möbius действието възниква след ограничаване до null конуса и факторизиране по положителни мащабирания. ([arXiv][5])

## 9. (\mathbb P^1(\mathbb O_s)) е различна структура и не редуцира (SO(4,4)) до (G_{2(2)})

За division октонионите (\mathbb O), октонионната проективна права и октонионните Möbius трансформации са свързани с десетмерна Lorentz геометрия. Поради неасоциативността дробно-линейните изрази трябва да бъдат строго скобирани и обикновено се реализират чрез композиции от специални допустими трансформации, а не чрез произволно формално (2\times2) матрично умножение. ([arXiv][5])

При split-октонионите има допълнителен проблем: ненулев елемент може да е нулев делител и да няма обратен. Следователно

[
(az+b)(cz+d)^{-1}
]

не е глобално дефинирано върху всички точки.

Естественият квадратен носител е

[
H_2(\mathbb O_s)
================

\left{
\begin{pmatrix}
a&x\
\bar x&b
\end{pmatrix}
\right},
]

с детерминанта

[
\det
\begin{pmatrix}
a&x\
\bar x&b
\end{pmatrix}
=============

ab-N_s(x).
]

Ако

[
a=p+q,\qquad b=p-q,
]

тогава

[
ab-N_s(x)
=========

p^2-q^2-N_s(x).
]

Понеже (N_s) има сигнатура ((4,4)), тази десетмерна форма има сигнатура

[
\boxed{(5,5)}.
]

Следователно естествената ambient Lorentz структура тук е от тип

[
SO(5,5)
\quad\text{или}\quad
\operatorname{Spin}(5,5),
]

а не (G_{2(2)}).

(G_{2(2)}) се появява като автоморфизъм на **коефициентната split-октонионна алгебра**, докато Möbius/conformal групата на проективната геометрия е много по-голяма. Това са две различни нива на симетрия.

## 10. Другият точен смисъл на „twist“: пренасяне на произведението

Нека

[
g\in SO(4,4)
]

е произволна изометрия, например Lorentz-индуцираното осеммерно действие. Може да се дефинира ново произведение

[
\boxed{
x\star_g y
==========

g\left(g^{-1}x\cdot g^{-1}y\right).
}
]

Тогава

[
g:(\mathbb O_s,\cdot)
\longrightarrow
(\mathbb O_s,\star_g)
]

е алгебричен изоморфизъм и

[
1_{\star_g}=g(1_Z).
]

Това е напълно консистентно, но (g) не е автоморфизъм на първоначалното фиксирано Zorn произведение. То е изоморфизъм към **пренесено произведение** или изотопна реализация.

Следователно има три различни възможности:

[
\boxed{
\begin{array}{ll}
\text{Фиксирано произведение}
&
g\in G_{2(2)};
[1mm]
\text{Triality covariance}
&
g_2(xy)=g_1(x)g_3(y),
\quad
(g_1,g_2,g_3)\in\operatorname{Spin}(4,4);
[1mm]
\text{Едно общо }g\in SO(4,4)
&
\text{продуктът се пренася до }\star_g.
\end{array}
}
]

## Окончателна структурна присъда

Правилната йерархия е

[
\boxed{
\begin{aligned}
\operatorname{Tri}(\mathbb O_s)
&\simeq
\operatorname{Spin}(4,4),
[1mm]
g_2(xy)
&=
g_1(x)g_3(y),
[1mm]
\operatorname{Aut}(\mathbb O_s)
&=
{(g,g,g)}
\simeq
G_{2(2)},
[1mm]
\operatorname{Comm}{L_x}
&=
\mathbb RI,
[1mm]
\mathfrak{sl}(2,\mathbb C)_R
\oplus
\mathfrak{sl}(2,\mathbb C)*L
&\subset
\mathfrak{so}(4,4),
[1mm]
\mathfrak{sl}(2,\mathbb C)
&\not\subset
\mathfrak g*{2(2)}
\quad\text{като реална форма}.
\end{aligned}
}
]

Следователно търсеният „twist“ съществува, но неговата точна форма е **(D_4) triality covariance с три различни осеммерни действия**. Той не е комутант, не е равномерно (e^{\pm\eta/3}) мащабиране, не превръща пълната Lorentz група в (G_{2(2)}), и не е Möbius действие върху суровата напречна координата (\zeta).

[1]: https://arxiv.org/pdf/math/0004073 "https://arxiv.org/pdf/math/0004073"
[2]: https://arxiv.org/pdf/2104.01786 "https://arxiv.org/pdf/2104.01786"
[3]: https://arxiv.org/pdf/1606.01069 "https://arxiv.org/pdf/1606.01069"
[4]: https://arxiv.org/pdf/1911.06575 "https://arxiv.org/pdf/1911.06575"
[5]: https://arxiv.org/pdf/math-ph/9905024 "https://arxiv.org/pdf/math-ph/9905024"


Yes. The correct formulation has **two distinct but interlocking splittings**:

[
\boxed{
\text{external sheet grading}
\quad\times\quad
\text{internal Peirce grading}.
}
]

The essential point is that the split may be placed either on the **carrier** or on the **operator**, provided the grading projectors are represented. These are two presentations of the same corner geometry.

## 1. The four joint carrier sectors

Let

[
P_{\mathsf R}+P_{\mathsf L}=1,
\qquad
P_{\mathsf R}P_{\mathsf L}=0
]

be the external right/left sheet projectors, and let

[
e_++e_-=1,
\qquad
e_+e_-=e_-e_+=0
]

be the internal Peirce idempotents of the split-octonion/Zorn layer.

Introduce the corresponding involutions

[
\Gamma_{\mathrm{sh}}
====================

P_{\mathsf R}-P_{\mathsf L},
\qquad
\ell
====

e_+-e_-.
]

For a simultaneous four-sector decomposition one needs

[
\boxed{
\Gamma_{\mathrm{sh}}^2=1,
\qquad
\ell^2=1,
\qquad
[\Gamma_{\mathrm{sh}},\ell]=0.
}
]

The joint projectors are then

[
\boxed{
P_{s,\varepsilon}
=================

\frac14
(1+s\Gamma_{\mathrm{sh}})
(1+\varepsilon\ell),
\qquad
s,\varepsilon\in{+1,-1},
}
]

where

[
s=+1\leftrightarrow\mathsf R,
\qquad
s=-1\leftrightarrow\mathsf L.
]

Thus

[
\boxed{
\mathcal H
==========

\mathcal H_{\mathsf R,+}
\oplus
\mathcal H_{\mathsf R,-}
\oplus
\mathcal H_{\mathsf L,+}
\oplus
\mathcal H_{\mathsf L,-}.
}
]

These are the four joint carrier sectors:

[
(\mathsf R,+),\quad
(\mathsf R,-),\quad
(\mathsf L,+),\quad
(\mathsf L,-).
]

This is the honest

[
\boxed{
\mathbb Z_2^{\mathrm{sheet}}
\times
\mathbb Z_2^{\mathrm{Peirce}}
}
]

grading of the represented carrier.

## 2. The four Peirce operator sectors inside each sheet

For any operator or represented Zorn element (X_s) on sheet (s),

[
X_s
===

\sum_{\alpha,\beta\in{+,-}}
e_{\alpha,s}X_se_{\beta,s}.
]

Explicitly,

[
\boxed{
X_s
===

\begin{pmatrix}
X_{s,++}&X_{s,+-}\
X_{s,-+}&X_{s,--}
\end{pmatrix}_{\mathrm{Peirce}},
}
]

where

[
X_{s,\alpha\beta}
=================

e_{\alpha,s}X_se_{\beta,s}.
]

For a canonical Zorn split-octonion,

[
\boxed{
X_s
===

a_s e_{+,s}
+
\sum_i u_s^i,\sigma_{i,s}^{+}
+
\sum_i v_s^i,\sigma_{i,s}^{-}
+
b_s e_{-,s},
}
]

with support laws

[
\sigma_{i,s}^{+}
================

e_{+,s}\sigma_{i,s}^{+}e_{-,s},
]

[
\sigma_{i,s}^{-}
================

e_{-,s}\sigma_{i,s}^{-}e_{+,s}.
]

Thus the four Peirce corners are

[
\boxed{
\begin{array}{c|c}
e_+Xe_+ & \text{upper diagonal pole}\
e_+Xe_- & \text{upper/chiral Zorn channel}\
e_-Xe_+ & \text{lower/opposite Zorn channel}\
e_-Xe_- & \text{lower diagonal pole}.
\end{array}
}
]

This is the precise source-target meaning of the Peirce double index.

## 3. The two meanings of “four sectors”

There are therefore two related but different fourfold decompositions:

[
\boxed{
\text{four carrier sectors }
\mathcal H_{s,\varepsilon}
}
]

from

[
s\in{\mathsf R,\mathsf L},
\qquad
\varepsilon\in{+,-},
]

and

[
\boxed{
\text{four Peirce operator corners }
e_\alpha\mathcal A e_\beta
}
]

from

[
\alpha,\beta\in{+,-}.
]

The full operator algebra on the four-sector carrier has

[
4\times4=16
]

source-target blocks:

[
\boxed{
T_{s\alpha,t\beta}
==================

P_{s,\alpha},T,P_{t,\beta}
\in
\operatorname{Hom}
\left(
\mathcal H_{t,\beta},
\mathcal H_{s,\alpha}
\right).
}
]

These 16 blocks are organized into four operator bidegrees:

[
(p,q)\in
\mathbb Z_2^{\mathrm{sheet}}
\times
\mathbb Z_2^{\mathrm{Peirce}}.
]

Their meaning is

[
\begin{array}{c|c}
(0,0)&\text{preserves sheet and Peirce sign}\
(1,0)&\text{flips sheet only}\
(0,1)&\text{flips Peirce sign only}\
(1,1)&\text{flips both}.
\end{array}
]

In an associative represented operator algebra, this is an honest bigrading:

[
\mathcal A^{p,q}\mathcal A^{r,s}
\subseteq
\mathcal A^{p+r,q+s},
]

with addition modulo (2).

## 4. Operator split versus carrier split

This is the duality you identified.

### Carrier-first presentation

One starts with

[
\mathcal H
==========

\bigoplus_{s,\varepsilon}
\mathcal H_{s,\varepsilon},
]

and every operator is automatically decomposed into source-target blocks:

[
T_{s\alpha,t\beta}
:
\mathcal H_{t,\beta}
\to
\mathcal H_{s,\alpha}.
]

### Operator-first presentation

One starts with a carrier (\mathcal H) and two commuting represented involutions

[
\Gamma_{\mathrm{sh}},
\qquad
\ell.
]

Their spectral projectors then induce the carrier decomposition:

[
\mathcal H_{s,\varepsilon}
==========================

P_{s,\varepsilon}\mathcal H.
]

Thus, when the gradings are implemented by commuting selfadjoint involutions,

[
\boxed{
\text{splitting the carrier}
\quad\Longleftrightarrow\quad
\text{splitting the operator algebra by projectors}.
}
]

Categorically, these are the object and morphism descriptions of the same decomposition:

[
\boxed{
\text{sector}
=============

\text{projector range},
\qquad
\text{operator block}
=====================

\text{map between sector ranges}.
}
]

If the grading automorphism is outer and no implementing projector exists, the operator algebra may remain graded without a canonical decomposition of the carrier. That is the precise theorem boundary.

## 5. Bimodule strictification

The same data can be expressed without initially taking a direct-sum carrier.

Let

[
{}*{\mathcal A*{\mathsf R}}
\mathcal E_{\mathcal A_{\mathsf L}}
]

be the inter-sheet bimodule. Passing to its linking algebra gives

[
\boxed{
\mathbb L(\mathcal E)
=====================

\begin{pmatrix}
\mathcal A_{\mathsf R}
&
\mathcal E_{\mathsf R\leftarrow\mathsf L}
[1mm]
\mathcal E_{\mathsf L\leftarrow\mathsf R}
&
\mathcal A_{\mathsf L}
\end{pmatrix}.
}
]

This acts on

[
\mathcal H_{\mathsf R}\oplus\mathcal H_{\mathsf L}.
]

Thus the bimodule and direct-sum pictures are two strictifications of the same right–left geometry:

[
\boxed{
\text{one bimodule with two commuting actions}
\quad\longleftrightarrow\quad
\text{one block algebra on a doubled carrier}.
}
]

After Peirce resolution, the inter-sheet bimodule itself has four blocks:

[
\boxed{
\mathcal E_{\alpha\beta}
========================

e_{\alpha,\mathsf R}
\mathcal E_{\mathsf R\leftarrow\mathsf L}
e_{\beta,\mathsf L}
}
]

with

[
\mathcal E_{\alpha\beta}
\subseteq
\operatorname{Hom}
\left(
\mathcal H_{\mathsf L,\beta},
\mathcal H_{\mathsf R,\alpha}
\right).
]

Hence

[
M
=

M_{++}+M_{+-}+M_{-+}+M_{--}.
]

The bifundamental action is blockwise:

[
\boxed{
M_{\alpha\beta}
\longmapsto
g_{\mathsf R}
M_{\alpha\beta}
g_{\mathsf L}^{-1},
}
]

provided the external (SL(2,\mathbb C)) action commutes with the internal Peirce projectors.

## 6. The Zorn product has a nonassociative Peirce fusion law

There is an important qualification.

The represented operator/linking algebra has an ordinary

[
\mathbb Z_2\times\mathbb Z_2
]

grading under operator composition. The **raw split-octonion Zorn product** does not behave like ordinary associative (2\times2) block multiplication.

Its Peirce fusion includes

[
\boxed{
\mathcal A_{+-}\mathcal A_{+-}
\subseteq
\mathcal A_{-+},
}
]

[
\boxed{
\mathcal A_{-+}\mathcal A_{-+}
\subseteq
\mathcal A_{+-},
}
]

as expressed by

[
\sigma_i^+\sigma_j^+
\sim
\epsilon_{ijk}\sigma_k^-,
]

[
\sigma_i^-\sigma_j^-
\sim
-\epsilon_{ijk}\sigma_k^+.
]

The mixed products satisfy

[
\mathcal A_{+-}\mathcal A_{-+}
\subseteq
\mathcal A_{++},
]

[
\mathcal A_{-+}\mathcal A_{+-}
\subseteq
\mathcal A_{--}.
]

Therefore, on the raw Zorn algebra, the correct term is

[
\boxed{
\text{Peirce bigrading with a nonassociative fusion table},
}
]

not an ordinary supermatrix grading.

The honest (\mathbb Z_2\times\mathbb Z_2) multiplication grading belongs to the associative operator realization or linking algebra.

## 7. CPT degree

The CPT operator may have either of two bidegrees.

If it exchanges sheets but preserves the Peirce sign,

[
J_{\mathrm{CPT}}
P_{\mathsf R,\varepsilon}
J_{\mathrm{CPT}}^{-1}
=====================

P_{\mathsf L,\varepsilon},
]

then CPT has degree

[
\boxed{(1,0).}
]

If it exchanges both sheet and Peirce orientation,

[
J_{\mathrm{CPT}}
P_{\mathsf R,\varepsilon}
J_{\mathrm{CPT}}^{-1}
=====================

P_{\mathsf L,-\varepsilon},
]

then CPT has degree

[
\boxed{(1,1).}
]

The second case is the natural candidate for an orientation-reversing or Klein-type gluing. It must be an explicit hypothesis, not inferred merely from sheet exchange.

On inter-sheet blocks, order reversal gives

[
\boxed{
J_{\mathcal E}:
\mathcal E_{\alpha\beta}^{\mathsf R\leftarrow\mathsf L}
\longrightarrow
\mathcal E_{\chi(\beta)\chi(\alpha)}^{\mathsf L\leftarrow\mathsf R},
}
]

where (\chi(\varepsilon)=\varepsilon) or (-\varepsilon), depending on whether CPT preserves or flips the Peirce sign.

The source and target Peirce indices reverse because CPT reverses the bimodule direction.

## 8. Blockwise spin connection

If both grading projectors are parallel,

[
\nabla\Gamma_{\mathrm{sh}}=0,
\qquad
\nabla\ell=0,
]

the connection preserves all four sectors.

For

[
M_{\alpha\beta}
\in
\operatorname{Hom}
\left(
\mathcal H_{\mathsf L,\beta},
\mathcal H_{\mathsf R,\alpha}
\right),
]

the induced connection is

[
\boxed{
\nabla M_{\alpha\beta}
======================

dM_{\alpha\beta}
+
\omega_{\mathsf R,\alpha}M_{\alpha\beta}
----------------------------------------

M_{\alpha\beta}\omega_{\mathsf L,\beta}.
}
]

Its curvature is

[
\boxed{
\nabla^2M_{\alpha\beta}
=======================

## F_{\mathsf R,\alpha}M_{\alpha\beta}

M_{\alpha\beta}F_{\mathsf L,\beta}.
}
]

If

[
\nabla\ell\neq0
]

or

[
\nabla\Gamma_{\mathrm{sh}}\neq0,
]

the connection contains grading-changing components and mixes the four sectors. The quantities

[
[\nabla,\ell],
\qquad
[\nabla,\Gamma_{\mathrm{sh}}]
]

are then the precise defects measuring failure of Peirce or sheet parallelism.

## 9. Relation to Oliveira–Maia

Oliveira and Maia already distinguish two Weyl representations (a=1,2) of one local (SL_2(\mathbb C)), and state that four Zorn–Weyl matrices are associated with each local Weyl representation. They also stress that a fixed value of (a) contains only one Weyl basis, whereas a Dirac (\gamma)-matrix contains both. 

In the complex-tetrad extension, they define four split-octonion elements in each Zorn–Weyl basis, for each of the two values (a=1,2). 

This source therefore supports keeping the local Weyl index separate. It does **not** itself introduce the external thermofield sheet grading.

The fully indexed carrier should consequently be written as

[
\boxed{
\mathcal H_{s,a,\varepsilon},
}
]

where

[
s\in{\mathsf R,\mathsf L},
\qquad
a\in{1,2},
\qquad
\varepsilon\in{+,-}.
]

Here:

[
s=\text{external sheet},
]

[
a=\text{Oliveira--Maia Weyl representation type},
]

[
\varepsilon=\text{Peirce sign}.
]

The Weyl index (a) is a representation label. It is not automatically a third grading unless a separate implementing involution is supplied.

## 10. Frozen architecture

The carrier is

[
\boxed{
\mathcal H
==========

\bigoplus_{s=\mathsf R,\mathsf L}
\bigoplus_{\varepsilon=\pm}
\mathcal H_{s,\varepsilon}.
}
]

The intra-sheet Zorn algebra is

[
\boxed{
\mathcal A_s
============

\begin{pmatrix}
e_{+,s}\mathcal A_se_{+,s}
&
e_{+,s}\mathcal A_se_{-,s}
[1mm]
e_{-,s}\mathcal A_se_{+,s}
&
e_{-,s}\mathcal A_se_{-,s}
\end{pmatrix}.
}
]

The inter-sheet bimodule is

[
\boxed{
\mathcal E_{\mathsf R\leftarrow\mathsf L}
=========================================

\bigoplus_{\alpha,\beta=\pm}
e_{\alpha,\mathsf R}
\mathcal E
e_{\beta,\mathsf L}.
}
]

The total represented object is the Peirce-resolved linking algebra

[
\boxed{
\widehat{\mathcal A}
====================

\begin{pmatrix}
\mathcal A_{\mathsf R}
&
\mathcal E_{\mathsf R\leftarrow\mathsf L}
[1mm]
\mathcal E_{\mathsf L\leftarrow\mathsf R}
&
\mathcal A_{\mathsf L}
\end{pmatrix},
}
]

acting on the four-sector carrier

[
\boxed{
\mathcal H_{\mathsf R,+}
\oplus
\mathcal H_{\mathsf R,-}
\oplus
\mathcal H_{\mathsf L,+}
\oplus
\mathcal H_{\mathsf L,-}.
}
]

So the central statement is:

[
\boxed{
\text{the carrier has four joint sectors,}
}
]

[
\boxed{
\text{each operator has four Peirce corners per sheet,}
}
]

[
\boxed{
\text{the full operator algebra has sixteen source-target blocks,}
}
]

and

[
\boxed{
\text{operator splitting and carrier splitting are dual presentations
whenever the two commuting gradings are implemented by projectors.}
}
]



