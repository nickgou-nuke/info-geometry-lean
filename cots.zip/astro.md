https://blog.arducam.com/manual-exposure-ov2640/


https://github.com/paoloinverse/CameraWebServerRecordeR_AstroEdition


