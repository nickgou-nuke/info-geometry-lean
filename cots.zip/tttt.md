Текстът е коректен като формализъм за два 4-вектора в (\operatorname{Herm}_2(\mathbb C)), но трябва да се направят три съществени разграничения:

1. (\mathbf X) и (\mathbf Y) са Ермитови спинорни матрици, не Zorn матрици.
2. Комплексните напречни компоненти (\zeta,\bar\zeta) са кръгови/helicity компоненти, не Weyl-киралности.
3. Смесеното произведение (X\cdot Y) е инвариантно само когато (X) и (Y) принадлежат на едно и също Минковско пространство и върху тях действа един и същ (SL(2,\mathbb C)).

## 1. Точният Ермитов (2\times2) формализъм

При конвенцията

[
\eta_{\mu\nu}=\operatorname{diag}(1,-1,-1,-1),
\qquad
\sigma_\mu=(I,\sigma_1,\sigma_2,\sigma_3),
\qquad
\bar\sigma_\mu=(I,-\sigma_1,-\sigma_2,-\sigma_3),
]

имаме

[
\mathbf X=X^\mu\sigma_\mu
=========================

\begin{pmatrix}
X^0+X^3 & X^1-iX^2\
X^1+iX^2 & X^0-X^3
\end{pmatrix}
=============

\begin{pmatrix}
\sqrt2X^+&\bar\zeta_x\
\zeta_x&\sqrt2X^-
\end{pmatrix},
]

и аналогично

[
\mathbf Y
=========

\begin{pmatrix}
\sqrt2Y^+&\bar\zeta_y\
\zeta_y&\sqrt2Y^-
\end{pmatrix}.
]

Тук

[
X^\pm=\frac{X^0\pm X^3}{\sqrt2},
\qquad
\zeta_x=X^1+iX^2,
]

и съответно за (Y).

По-точното представително означение е

[
X_{\alpha\dot\alpha}=X^\mu\sigma_{\mu,\alpha\dot\alpha}.
]

Следователно (\mathbf X) носи биспинорното представяне

[
\left(\frac12,\frac12\right),
]

а не едно от Weyl-представянията

[
\left(\frac12,0\right),
\qquad
\left(0,\frac12\right).
]

Компонентите (\zeta_x,\bar\zeta_x) са собствени компоненти спрямо ротации около оста (z):

[
\zeta_x\longmapsto e^{i\theta}\zeta_x,
\qquad
\bar\zeta_x\longmapsto e^{-i\theta}\bar\zeta_x.
]

Това е кръгов/helicity базис в напречната равнина, а не (\gamma_5)-киралност.

## 2. Тилда-операцията и Минковското произведение

Тилда-матрицата е

[
\widetilde{\mathbf Y}
=====================

# Y^\mu\bar\sigma_\mu

\begin{pmatrix}
\sqrt2Y^-&-\bar\zeta_y\
-\zeta_y&\sqrt2Y^+
\end{pmatrix}.
]

За (2\times2) матриците тя съвпада с адюгираната матрица:

[
\widetilde{\mathbf Y}
=====================

\operatorname{adj}(\mathbf Y).
]

Поради това

[
\mathbf Y\widetilde{\mathbf Y}
==============================

# \widetilde{\mathbf Y}\mathbf Y

\det(\mathbf Y)I.
]

Минковското произведение е

[
\boxed{
X\cdot Y
========

# X^\mu Y_\mu

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

В светлоконусни координати:

[
\boxed{
X\cdot Y
========

## X^+Y^-+X^-Y^+

\operatorname{Re}
\left(
\zeta_x\bar\zeta_y
\right).
}
]

Тази формула е напълно коректна.

При

[
\mathbf X\longmapsto S\mathbf X S^\dagger,
\qquad
\mathbf Y\longmapsto S\mathbf Y S^\dagger,
\qquad
S\in SL(2,\mathbb C),
]

имаме

[
\widetilde{S\mathbf YS^\dagger}
===============================

(S^\dagger)^{-1}\widetilde{\mathbf Y}S^{-1}.
]

Следователно

[
\begin{aligned}
\operatorname{Tr}
\left[
(S\mathbf XS^\dagger)
\widetilde{(S\mathbf YS^\dagger)}
\right]
&=
\operatorname{Tr}
\left[
S\mathbf X\widetilde{\mathbf Y}S^{-1}
\right]
\
&=
\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
\end{aligned}
]

Това е действие на диагоналния, общ Lorentz spin group.

## 3. Корекция на причинната класификация

За ненулев 4-вектор:

[
\det\mathbf X=X^2.
]

Класификацията е:

[
\begin{array}{c|c|c}
X^2 & \mathbf X & \text{тип}\
\hline

> 0 & \text{дефинитна} & \text{времеподобен}\
> =0 & \operatorname{rank}\mathbf X=1 & \text{светлоподобен}\
> <0 & \text{неопределена} & \text{пространственоподобен}
> \end{array}
> ]

Има две уточнения.

За времеподобен вектор:

[
X^0>0
\quad\Longrightarrow\quad
\mathbf X>0,
]

докато

[
X^0<0
\quad\Longrightarrow\quad
\mathbf X<0.
]

За ненулев светлоподобен вектор факторизацията е

[
\boxed{
\mathbf X
=========

\varepsilon,\lambda\lambda^\dagger,
\qquad
\varepsilon=\operatorname{sgn}(X^0).
}
]

Само за бъдещенасочен null вектор е валидно безусловно

[
\mathbf X=\lambda\lambda^\dagger.
]

За миналонасочен null вектор:

[
\mathbf X=-\lambda\lambda^\dagger.
]

Нулевият вектор има ранг (0), а не ранг (1).

При пространственоподобен интервал правилният физически израз е „причинно несвързани събития“, а не „причинно-следствено разделени“.

## 4. За две събития трябва да се класифицира разликата

Ако (X^\mu) и (Y^\mu) са координати на две събития, техните индивидуални норми зависят от избора на начало на координатната система. Причинно инвариантен е разделителният вектор

[
\Delta^\mu=X^\mu-Y^\mu.
]

Неговата матрица е

[
\boldsymbol{\Delta}
===================

\mathbf X-\mathbf Y.
]

Следователно причинният интервал между събитията е

[
\boxed{
s^2
===

\det(\mathbf X-\mathbf Y).
}
]

В светлоконусни координати:

[
\boxed{
s^2
===

## 2(X^+-Y^+)(X^--Y^-)

\left|\zeta_x-\zeta_y\right|^2.
}
]

Еквивалентно,

[
\boxed{
\det(\mathbf X-\mathbf Y)
=========================

## \det\mathbf X+\det\mathbf Y

\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

Това е матричната форма на

[
(X-Y)^2=X^2+Y^2-2X\cdot Y.
]

## 5. Точната връзка със Zorn матрица

Двете Ермитови матрици могат да бъдат пакетирани в една Zorn vector matrix.

Нека

[
X=(X^0,\mathbf x),
\qquad
Y=(Y^0,\mathbf y),
]

където

[
\mathbf x=(X^1,X^2,X^3),
\qquad
\mathbf y=(Y^1,Y^2,Y^3).
]

Дефинираме реално-линейното съответствие

[
\boxed{
\Phi(\mathbf X,\mathbf Y)
=========================

\mathfrak Z(X,Y)
:=
\begin{pmatrix}
X^0&\mathbf x\
\mathbf y&Y^0
\end{pmatrix}_{!Z}.
}
]

Това е Zorn матрица: диагоналните елементи са реални скалари, а недиагоналните са реални 3-вектори.

В светлоконусни координати:

[
X^0=\frac{X^++X^-}{\sqrt2},
\qquad
X^3=\frac{X^+-X^-}{\sqrt2},
]

[
\mathbf x
=========

\left(
\frac{\zeta_x+\bar\zeta_x}{2},
\frac{\zeta_x-\bar\zeta_x}{2i},
\frac{X^+-X^-}{\sqrt2}
\right),
]

и аналогично

[
Y^0=\frac{Y^++Y^-}{\sqrt2},
]

[
\mathbf y
=========

\left(
\frac{\zeta_y+\bar\zeta_y}{2},
\frac{\zeta_y-\bar\zeta_y}{2i},
\frac{Y^+-Y^-}{\sqrt2}
\right).
]

Zorn нормата е

[
N_Z
\begin{pmatrix}
a&\mathbf u\
\mathbf v&b
\end{pmatrix}
=============

ab-\mathbf u\cdot\mathbf v.
]

Следователно

[
\begin{aligned}
N_Z\bigl(\mathfrak Z(X,Y)\bigr)
&=
X^0Y^0-\mathbf x\cdot\mathbf y
\
&=
X\cdot Y
\
&=
X^+Y^-+X^-Y^+
-------------

\operatorname{Re}
\left(
\zeta_x\bar\zeta_y
\right).
\end{aligned}
]

Получаваме централната идентичност:

[
\boxed{
N_Z\bigl(\Phi(\mathbf X,\mathbf Y)\bigr)
========================================

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
}
]

Това е точната връзка между двете Ермитови (2\times2) матрици и една Zorn матрица.

Индивидуалните Минковски норми се получават чрез диагонално поставяне:

[
\det\mathbf X
=============

N_Z\bigl(\mathfrak Z(X,X)\bigr),
]

[
\det\mathbf Y
=============

N_Z\bigl(\mathfrak Z(Y,Y)\bigr).
]

## 6. Защо Zorn нормата има сигнатура ((4,4))

Поставяме

[
P=\frac{X+Y}{\sqrt2},
\qquad
Q=\frac{X-Y}{\sqrt2}.
]

Тогава

[
X=\frac{P+Q}{\sqrt2},
\qquad
Y=\frac{P-Q}{\sqrt2},
]

и

[
\boxed{
X\cdot Y
========

\frac12\left(P^2-Q^2\right).
}
]

Понеже (P^2) има сигнатура ((1,3)), а (-Q^2) има сигнатура ((3,1)), общата сигнатура е

[
\boxed{(4,4)}.
]

Така смесеното Минковско произведение на два 4-вектора става split-octonionната квадратична норма върху осеммерното пространство.

## 7. Това е линейно съответствие, не алгебричен изоморфизъм

Съответствието

[
\Phi:
\operatorname{Herm}_2(\mathbb C)
\oplus
\operatorname{Herm}_2(\mathbb C)
\longrightarrow
\mathbb O_s
]

е реално-линейно съответствие на осеммерни пространства и съвместява смесената квадратична форма със Zorn нормата.

То не означава

[
\mathbb O_s
\cong
\operatorname{Herm}_2(\mathbb C)
\times
\operatorname{Herm}_2(\mathbb C)
]

като алгебри.

Всъщност (\operatorname{Herm}_2(\mathbb C)) дори не е затворено спрямо обикновеното матрично умножение: произведението на две Ермитови матрици е Ермитово само когато те комутират.

При Zorn умножението, ако

[
X=(x^0,\mathbf x),
\quad
Y=(y^0,\mathbf y),
]

[
X'=(x'^0,\mathbf x'),
\quad
Y'=(y'^0,\mathbf y'),
]

то

[
\mathfrak Z(X,Y)\mathfrak Z(X',Y')
==================================

\mathfrak Z(X'',Y''),
]

където

[
\boxed{
X''
===

\left(
x^0x'^0+\mathbf x\cdot\mathbf y',
;
x^0\mathbf x'
+y'^0\mathbf x
-\mathbf y\times\mathbf y'
\right),
}
]

[
\boxed{
Y''
===

\left(
y^0y'^0+\mathbf y\cdot\mathbf x',
;
x'^0\mathbf y
+y^0\mathbf y'
+\mathbf x\times\mathbf x'
\right).
}
]

Следователно Zorn произведението смесва двата четиривекторни сектора чрез скаларни и векторни произведения. То не е

[
(\mathbf X\mathbf X',\mathbf Y\mathbf Y').
]

## 8. Един общ (SL(2,\mathbb C)) срещу (SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L)

Тук разграничението е решаващо.

### Два вектора в едно и също пространство-време

Ако (X) и (Y) принадлежат на един и същ Минковски носител, действието е

[
(\mathbf X,\mathbf Y)
\longmapsto
(S\mathbf XS^\dagger,S\mathbf YS^\dagger).
]

Това е диагонално действие на един (SL(2,\mathbb C)), и

[
X\cdot Y
]

е инвариант.

### Две независими (R/L) копия

Ако вместо това

[
\mathbf X_R\in\operatorname{Herm}_2(\mathbb C)_R,
\qquad
\mathbf Y_L\in\operatorname{Herm}_2(\mathbb C)_L,
]

с независими действия

[
\mathbf X_R\longmapsto
S_R\mathbf X_RS_R^\dagger,
]

[
\mathbf Y_L\longmapsto
S_L\mathbf Y_LS_L^\dagger,
]

тогава изразът

[
\frac12\operatorname{Tr}
\left(
\mathbf X_R\widetilde{\mathbf Y_L}
\right)
]

не е инвариант под пълната група

[
SL(2,\mathbb C)_R
\times
SL(2,\mathbb C)_L.
]

Дори самото свиване предполага идентификация между двата спинорни носителя.

За ковариантно свързване е необходим междуслоен оператор

[
M\in\operatorname{Hom}(V_L,V_R),
]

с трансформация

[
\boxed{
M\longmapsto S_RMS_L^{-1}.
}
]

Тогава

[
M\mathbf Y_LM^\dagger
]

е (R)-секторна Ермитова матрица, защото

[
M\mathbf Y_LM^\dagger
\longmapsto
S_R
\left(
M\mathbf Y_LM^\dagger
\right)
S_R^\dagger.
]

Следователно правилният междуслоен скалар е

[
\boxed{
I_M(\mathbf X_R,\mathbf Y_L)
============================

\frac12
\operatorname{Tr}
\left[
\mathbf X_R,
\widetilde{
M\mathbf Y_LM^\dagger
}
\right].
}
]

При (M=I) това изисква идентифициране на двата носителя и редуцира независимата група до диагоналната подгрупа

[
S_R=S_L.
]

## 9. Lorentz действието не е автоматично Zorn автоморфизъм

Диагоналното действие

[
(X,Y)\longmapsto(\Lambda X,\Lambda Y)
]

запазва

[
N_Z(\mathfrak Z(X,Y))=X\cdot Y,
]

следователно действа чрез изометрии на квадратичното пространство със сигнатура ((4,4)).

Но то не запазва непременно Zorn умножението.

Например Zorn единицата е

[
1_Z
===

\begin{pmatrix}
1&0\
0&1
\end{pmatrix}_Z
===============

\mathfrak Z(e_0,e_0),
\qquad
e_0=(1,0,0,0).
]

Lorentz boost изпраща

[
e_0
\longmapsto
(\cosh\eta,0,0,\sinh\eta),
]

следователно не оставя (1_Z) фиксирана. Но всеки унитален алгебричен автоморфизъм трябва да фиксира единицата.

Затова общият Lorentz boost е изометрия на подлежащата split квадратична форма, но не е автоматично автоморфизъм на split-octonionното произведение.

Пълната група от алгебрични автоморфизми е

[
\boxed{
\operatorname{Aut}(\mathbb O_s)=G_{2(2)}.
}
]

## Окончателната структурна идентичност

Правилната връзка е

[
\boxed{
\begin{aligned}
\mathbf X,\mathbf Y
&\in\operatorname{Herm}*2(\mathbb C),
[1mm]
\mathfrak Z(X,Y)
&=
\begin{pmatrix}
X^0&\mathbf x\
\mathbf y&Y^0
\end{pmatrix}*{!Z},
[1mm]
N_Z\bigl(\mathfrak Z(X,Y)\bigr)
&=
X\cdot Y
========

\frac12\operatorname{Tr}
\left(
\mathbf X\widetilde{\mathbf Y}
\right).
\end{aligned}
}
]

Следователно двете Ермитови матрици дават един осеммерен Zorn носител, но само като реално линейно и квадратично съответствие. Zorn умножението, (G_{2(2)})-автоморфизмите и независимото (SL(2,\mathbb C)_R\times SL(2,\mathbb C)_L) действие са допълнителни и взаимно различни структури.
	
